 const formatNumeric = (amout: number): string => {
  return (amout).toLocaleString(
    undefined, // leave undefined to use the visitor's browser
    { minimumFractionDigits: 0 }
  );
};

export default formatNumeric;

export type LocationType = {
  latitude: string,
  longitude: string
}

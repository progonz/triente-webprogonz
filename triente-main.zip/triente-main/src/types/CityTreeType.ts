export type CityTreeType = {
  id: string,
  text: string,
  state: {
    checked: boolean,
    expanded: boolean,
  },
  checkable: boolean,
  selectable: boolean,
  nodes: CityTreeType[]
}

<template>
  <main id="main-container">
    <main class="main-container_main">
      <nav-bar/>

      <router-view v-slot="{Component}">
        <!--        <transition name="moveUp" mode="out-in">-->
        <transition name="fade" mode="out-in">
          <component :is="Component" :key="$route.path"></component>
        </transition>
      </router-view>

    </main>
    <Footer/>
  </main>
</template>
<script lang="ts">
import { Options, Vue } from 'vue-class-component';
import Footer from '@/components/smarts/footer/Footer.vue';
import NavBar from '@/components/smarts/ui-nav-bar/nav-bar/NavBar.vue';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import IActivity from '@/models/activity.model';
import IMaster from '@/models/maestre.model';
import router from '@/router';

@Options({
  components: {
    NavBar,
    Footer
  },
})
export default class App extends Vue {

  store = useStore<StateInterface>();

  async mounted(): Promise<void> {
    await this.store.dispatch('auth/isLogin');
    await this.store.dispatch('buildings/get');
    await this.store.dispatch('constructions/get');
    await this.store.dispatch('employees/get');
    await this.store.dispatch('provinces/get');
    const tupes = await this.store.dispatch('type_company/get');

    let type: any = localStorage.getItem('type');

    this.store.dispatch('type_company/selected',
        type && type !== 'undefined'
            ? JSON.parse(type) as IMaster
            : tupes[0]);

    let ac: any = localStorage.getItem('activity');
    if (ac !== 'undefined') {
      this.store.dispatch('activities/select', JSON.parse(ac) as IActivity);
    }
    let sc: any = localStorage.getItem('subActivity');
    if (sc !== 'undefined') {
      this.store.dispatch('sub_activities/select', JSON.parse(sc) as IActivity);
    }
    let fc: any = localStorage.getItem('filter');
    if (fc && fc !== 'undefined') {
      fc = JSON.parse(fc);

      fc?.buildings && !Array.isArray(fc.buildings) && (fc['buildings'] = Object.values(fc.buildings));
      fc?.constructions && !Array.isArray(fc.constructions) && (fc['constructions'] = Object.values(fc.constructions));
      fc?.employees && !Array.isArray(fc.employees) && (fc['employees'] = Object.values(fc.employees));
      if (fc)
        this.store.dispatch('companies/saveFilter', fc);

    }
  }

  get typeCompany(): IMaster[] {
    return this.store.getters['type_company/getItems'];
  }
}


</script>

<style lang="scss">
.app {
  width: 100vw;
}

#main-container {
  display: flex;
  flex-direction: column;
  width: 100%;
  min-height: 100vh;;

  .main-container_main {
    flex: 1;
    position: relative;
    //height: 90vh;
    min-height: 90vh;
    //overflow: auto;
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.15s;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

//.slide-enter-active,
//.slide-leave-active {
//  transition: opacity 1s, transform 1s;
//}
//.slide-enter-from,
//.slide-leave-to{
//  opacity: 0;
//  transform: translateX(-30%);
//}
//.moveUp-enter-active {
//  animation: fadeIn 1s ease-in;
//}
//
//@keyframes fadeIn {
//  0% {
//    opacity: 0
//  }
//  50% {
//    opacity: 0.5
//  }
//  100% {
//    opacity: 1
//  }
//
//}
//.modeUp-leave-active{
//  animation: moveUp 0.3s ease-in;
//}
//@keyframes moveUp {
//    0% {
//    transform: translateY(0);
//  }
//  100% {
//    transform: translateY(-400px);
//  }
//}
</style>

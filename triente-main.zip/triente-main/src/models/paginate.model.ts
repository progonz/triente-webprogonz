export interface IPaginate<T> {
  limit: number;
  total: number;
  page: number;
  lastPage?: number;
  nextPage?: number;
  pages: number;
  items: T[];
}

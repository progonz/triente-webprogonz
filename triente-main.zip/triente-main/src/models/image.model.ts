export interface IImage {
  mimetype: string;
  extension: string;
  content: string;
  url?: string;
  type: string;
}
export interface IUser {
    id?: string;
    name?: string;
    lastname?: string;
    password?: string;
    email: string;
    roles?: ROLES[];
    alerts?: IUserNotification;
}

export interface IUserNotification {
    new_profile: boolean;
    visualization: boolean;
    updates: boolean;
}

export enum ROLES {
    USER = 'ROLE_USER'
}

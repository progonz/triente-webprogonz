export interface IToken {
    access: string;
    refresh: string;
}

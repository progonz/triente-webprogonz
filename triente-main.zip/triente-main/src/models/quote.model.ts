export interface Quote {
    comment: string;
    avatar: string;
    name: string;
    profession: string;

}
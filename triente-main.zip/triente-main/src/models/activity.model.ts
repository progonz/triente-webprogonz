export interface IActivity {
    id: string;
    name: string;
    parent: string;
    total: number;
    totalChildren: number;
}

export default IActivity;

import { IAddress } from '@/models/address.model';

export class Project {
    id?: string;
    picture: string;
    name: string;
    address: IAddress;
    tags: string[];


}

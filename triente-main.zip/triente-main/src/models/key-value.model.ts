export interface IKeyValue {
    [k: string]: unknown
}

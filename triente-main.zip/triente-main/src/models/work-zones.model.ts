import faker from '@faker-js/faker';

export class WorkZones {
    country: string;
    companies: number;

    fake(): void {
        this.country = faker.address.state();
        this.companies = faker.datatype.number({
            max: 5000,
            min: 100
        });
    }
}

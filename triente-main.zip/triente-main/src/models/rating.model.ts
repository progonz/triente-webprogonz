import faker from '@faker-js/faker';

export class Rating {
    message: string;
    username: string;
    ranking: number;


    fake(): void {
        this.message = faker.random.words(45);
        this.username = faker.name.findName();
        this.ranking = faker.datatype.number({
            min: 1,
            max: 5
        });
    }


}

export class IAddress {
  id?: string;
  city: string;
  country: string;
  address?: string;
  province: string;
  community: string;
  zipcode: string;
}

export interface IProvince {
  province: string;
  cities: IAddress[];
}

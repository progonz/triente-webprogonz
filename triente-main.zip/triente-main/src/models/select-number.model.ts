export interface ISelectNumber {
  name: string;
  value: number;
}

export default ISelectNumber;
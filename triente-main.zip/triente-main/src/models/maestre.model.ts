export interface IMaster {
    id: string;
    name: string;
}

export default IMaster;
import { IAddress } from '@/models/address.model';
import IMaster from '@/models/maestre.model';
import IActivity from '@/models/activity.model';
import { IImage } from './image.model';

export interface ICompany {
  id?: string;
  type: string;
  name: string;
  description: string;
  cif: string;
  cnae: string;
  employees: string;
  address: IAddress;
  contact: IContact;
  buildings: IMaster[];
  activities: IActivity[];
  cities: IAddress[];
  constructions: IMaster[];
  area: IMinMax;
  budget: IMinMax;
  networks: INetworks[];
  images: IImage[];
}


export interface IContact {
  email: string;
  phone: string;
  website: string;
}

export interface INetworks {
  name: string;
  url: string;
}

export class IMinMax {
  min: number;
  max: number;

}


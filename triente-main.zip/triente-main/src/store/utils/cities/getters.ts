import {GetterTree} from "vuex";
import {StateInterface} from "@/store";
import {CitiesState} from "@/store/utils/cities/state";
import IMaster from "@/models/maestre.model";
import {IAddress} from "@/models/address.model";

const getters: GetterTree<CitiesState, StateInterface> = {
    getPage({items}: CitiesState): number {
        return items.page ?? 1;
    },
    getTotal({items}: CitiesState): number {
        return items.total ?? 0;
    },
    getItems({items}: CitiesState): IAddress[] {
        return items?.items ?? [];
    },
    isLoading({isLoading}: CitiesState): boolean {
        return isLoading;
    },
}
export default getters;

import {Module} from 'vuex';
import state, {CitiesState} from './state';
import actions from './actions';
import getters from './getters';
import mutations from './mutations';
import {StateInterface} from "@/store";


const citiesModule: Module<CitiesState, StateInterface> = {
    namespaced: true,
    actions,
    getters,
    mutations,
    state
}


export default citiesModule;
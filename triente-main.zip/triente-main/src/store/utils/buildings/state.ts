import IMaster from "@/models/maestre.model";
import {IPaginate} from "@/models/paginate.model";

export interface BuildingsState {
    isLoading: boolean;
    items: IPaginate<IMaster>
}

function state(): BuildingsState {
    return {
        isLoading: false,
        items: undefined,
    }
}

export default state;
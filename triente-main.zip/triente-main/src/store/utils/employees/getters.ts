import {GetterTree} from "vuex";
import {StateInterface} from "@/store";
import IMaster from "@/models/maestre.model";
import {EmployeesState} from "@/store/utils/employees/state";

const getters: GetterTree<EmployeesState, StateInterface> = {
    getPage({items}: EmployeesState): number {
        return items.page ?? 1;
    },
    getTotal({items}: EmployeesState): number {
        return items.total ?? 0;
    },
    getItems({items}: EmployeesState): IMaster[] {
        return items?.items ?? [];
    },
    isLoading({isLoading}: EmployeesState): boolean {
        return isLoading;
    },
}
export default getters;
import IMaster from "@/models/maestre.model";
import {IPaginate} from "@/models/paginate.model";

export interface EmployeesState {
    isLoading: boolean;
    items: IPaginate<IMaster>
}

function state(): EmployeesState {
    return {
        isLoading: false,
        items: undefined,
    }
}

export default state;
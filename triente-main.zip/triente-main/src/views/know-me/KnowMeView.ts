import {Options, Vue} from 'vue-class-component';
import {WorkZones} from "@/models/work-zones.model";
import QuotesSlider from "@/components/smarts/quotes-slider/QuotesSlider.vue";
import CompaniesCloseMe from "@/components/smarts/companies-close-me/CompaniesCloseMe.vue";
import FindCompanies from "@/components/smarts/find-companies/FindCompanies.vue";
import FAQs from "@/components/smarts/FAQs/FAQs.vue";
import BannerJoin from "@/components/smarts/banner-join/BannerJoin.vue";

@Options({
    components: {
        QuotesSlider,
        CompaniesCloseMe,
        FindCompanies,
        FAQs,
        BannerJoin
    },
})
export default class KnowMeView extends Vue {
    workZones: WorkZones[] = [];

    mounted(): void {
        window.scrollTo(0, 0);
        this.workZones = Array.from(new Array(15)).map(_ => {
            const zone = new WorkZones();
            zone.fake();
            return zone;
        });
    }

}

<script lang="ts"
        src="./KnowMeView.ts"/>
<style lang="scss">@import "KnowMeView";</style>
<template>
  <div class="know-me-view">
    <header class=" d-flex justify-content-end align-items-end">
      <div class="container d-flex">
        <div class="bg-white w-auto p-5 mb-5">
          <div class="fs-1 fw-bold">¿Cómo funciona Triente?</div>
          <div>Te ayudamos a tomar la decisión correcta</div>
        </div>
      </div>
    </header>
    <section class="container ">
      <div class="d-flex align-items-center py-5 flex-column-sm">
        <div class="w-100 p-5">
          <div class="info-content">
            <div class="fs-3">Localiza empresas en tu zona de trabajo</div>
            <div class="py-4">Puede que tengas que realizar un proyecto en una ubicación en la que no tienes a nadie de confianza. Triente te proporciona ese contacto, de calidad garantizada que te desbloqueará en el proceso de presupuestar.</div>
          </div>
        </div>
        <div class="w-100">
          <div class="d-flex  flex-nowrap flex-md-wrap align-items-center container-zone-work">
            <div class="zone-work     py-3"
                 v-for="(zone, index) in workZones"
                 :key="'zone-'+index">
              <div class="white-triangle"></div>
              <div class="fs-5 fw-bold text-center">{{ zone.country }}</div>
              <div class="text-center">{{ zone.companies }}</div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="bg-multi-points">
      <div class="container w-100">
        <div class="d-flex w-100 flex-column-sm align-items-center py-5 justify-content-around ">
          <div class="W-100 d-flex justify-content-center order-2 order-md-1">
            <img src="~@/assets/images/form-select.png"
                 alt="Form Demo">
          </div>
          <div class="W-100 p-5 d-flex justify-content-end order-1 order-md-2">
            <div class="info-content">
              <div class="fs-3">Selecciona candidatos por tipo de obra que necesitas ejecutar</div>
              <div class="py-4">Puede que tengas que realizar un proyecto en una ubicación en la que no tienes a nadie de confianza. Triente te proporciona ese contacto, de calidad garantizada que te desbloqueará en el proceso de presupuestar.</div>
            </div>
          </div>

        </div>
      </div>
    </section>
    <section class="container">
      <div class="row align-items-center py-5">
        <div class="col-12 col-md-6 p-5 d-flex ">
          <div class="info-content">
            <div class="fs-3">Afina tu busqueda acotando por el tipo de actividad específica</div>
            <div class="py-4">Puede que tengas que realizar un proyecto en una ubicación en la que no tienes a nadie de confianza. Triente te proporciona ese contacto, de calidad garantizada que te desbloqueará en el proceso de presupuestar.</div>
          </div>
        </div>
        <div class="col-12 col-md-6 d-flex justify-content-center">
          <img src="~@/assets/images/activity-search.png"
               alt="Form Demo">
        </div>


      </div>
    </section>
<!--
    <section class="container">

      <quotes-slider/>
    </section>
-->
    <section class="container">
      <CompaniesCloseMe/>
    </section>
    <div class="my-4">

      <find-companies/>
    </div>
<!--    <section class="container d-flex justify-content-center align-items-center">-->
<!--      <div class="w-100">-->
<!--        <f-a-qs/>-->
<!--      </div>-->
<!--    </section>-->
    <section class="container">
      <banner-join/>
    </section>
  </div>
</template>



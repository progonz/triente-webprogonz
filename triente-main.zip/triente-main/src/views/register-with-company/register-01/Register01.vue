<script lang="ts"
        src="./Register01.ts"/>
<style lang="scss">@import "Register01";</style>
<template>
  <div class="Register01 container">
    <div class="py-2 py-md-5"></div>
    <div class="row ">
      <div class="col-6 hidden-xs" >
        <div style="max-width: 330px">
          <div class="fs-2 ">Configuremos el perfil de tu empresa</div>
          <div class="py-3">Si tu empresa ya está dada de alta ponte en contacto con nosotros y te diremos los pasos a seguir</div>

        </div>
      </div>
      <div class="col-12 col-md-6">
        <div class="fs-3 pb-3"> ¿Cuál es el nombre de tu empresa?</div>

        <ui-text label="Crea o escribe el nombre de tu empresa"
                 id="name"
                 :model-value="name"
                 :vuelidate="v$.name"
                 @update:model-value="name = $event"
                 placeholder="Fernández y Molina S.R.L."/>
        <button type="button"
                @click="onContinue()"
                class="btn btn-primary  mt-5 ">
          Siguiente
        </button>
      </div>
    </div>
  </div>
</template>

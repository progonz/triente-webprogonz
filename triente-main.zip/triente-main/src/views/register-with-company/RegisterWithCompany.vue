<script lang="ts"
        src="./RegisterWithCompany.ts"/>
<style lang="scss">@import "RegisterWithCompany";</style>
<template>
  <div class="RegisterWithCompany">
    <div id="stepper-rwc"
         class="d-flex gap-5 justify-content-center align-items-md-center flex-column-sm">

      <router-link to="/rwc/01"
                   class="menu-rwc"
                   v-slot="{ isExactActive  }"
                   exact>
        <div class="title-rwc-option">
          <span class="stepper_num">1</span>
          Indica cuál es tu empresa
        </div>
        <div v-if="isMobile && isExactActive"
             class="section-mobile-active">
          <router-view></router-view>
        </div>
      </router-link>
      <router-link to="/rwc/02"
                   class="menu-rwc"
                   v-slot="{ isExactActive  }"
                   exact>

        <div class="title-rwc-option">
          <span class="stepper_num">2</span>
          Añade la información
        </div>
        <div v-if="isMobile && isExactActive"
             class="section-mobile-active">
          <router-view></router-view>
        </div>
      </router-link>
      <router-link to="/rwc/03"
                   v-if="!isLogged"
                   class="menu-rwc mb-xs-5"
                   v-slot="{ isExactActive  }"
                   exact>

        <div class="title-rwc-option">
          <span class="stepper_num">3</span>
          Crea tu cuenta de administrador
        </div>

        <div v-if="isMobile && isExactActive"
             class="section-mobile-active">
          <router-view></router-view>
        </div>
      </router-link>

    </div>
    <div v-if="!isMobile">
      <router-view></router-view>
    </div>
  </div>
</template>

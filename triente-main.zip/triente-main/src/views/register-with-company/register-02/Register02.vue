<script lang="ts"
        src="./Register02.ts"></script>
<style lang="scss">@import "Register02";</style>
<template>
  <div class="py-2 py-md-5"></div>
  <div class="Register02 container ">
    <div class="row">
      <div class="col-12" />
      <div class="col-6 hidden-xs">
        <div class="fs-3" style="max-width: 330px">Configuremos el perfil de tu empresa</div>
      </div>
      <div class="col-12 col-md-6">
        <accordion-vuelidate
          :vuelidate="v$.form" :sections="['company','contact','function','cities']"
          @finished="onFinished"
        >
          <template v-slot:title-company>Datos de la empresa</template>
          <template v-slot:form-company>
            <company-data
              :form="form.company"
              :vuelidate="v$.form?.company"
            />
          </template>
          <template v-slot:info-company>
            <div>{{ getType(form.company.type) }}</div>
            <div>{{ form.company.name }}</div>
            <div>{{ form.company?.address?.address }}, {{ form.company?.address?.country }},
              {{ form.company?.address?.city }}, {{ form.company?.address?.zipcode }},
            </div>
          </template>
          <template v-slot:title-contact>Datos de contacto</template>
          <template v-slot:form-contact>
            <company-contact
                :form="form.contact"
                :vuelidate="v$.form.contact"></company-contact>
          </template>
          <template v-slot:info-contact>
            <div>{{ form.contact?.email }}</div>
            <div>{{ form.contact?.phone }}</div>
            <div v-for="(net, index) in form.contact?.networks??[]" :key="'net'+index">
              <strong>{{ net.name }}</strong>
              : {{ net.url }}:
            </div>
          </template>
          <template v-slot:form-function>
            <company-function
              :form="form.function"
              :type="form.company.type"
              :vuelidate="v$.form.function"
            />
          </template>
          <template v-slot:info-function>
            <div>
              <span v-for="ac in form.function.activities" :key="ac.id">{{ ac.name }} |</span>
            </div>
            <div>
              <span v-for="ac in form.function.buildings" :key="ac.id">{{ ac.name }} |</span>
            </div>
            <div>
              <span v-for="ac in form.function.constructions" :key="ac.id">{{ ac.name }} |</span>
            </div>

            <div>
              Area: {{ form.function.area.min }} - {{ form.function.area.max }}m²
            </div>
            <div>
              Importe de proyectos: {{ form.function?.amount?.min ?? 0 }} - {{ form.function?.amount?.max ?? 0 }} €
            </div>
            <div>
              Empleados: {{ form.function.employees?.name }}
            </div>
          </template>
          <template v-slot:title-function>¿A qué se dedica tu empresa?</template>
          <template v-slot:form-cities>
            <company-performance :form="form.cities"
              :vuelidate="v$.form.cities"
              @update:form="form.cities = $event"></company-performance>
          </template>
          <template v-slot:info-cities>
          </template>
          <template v-slot:title-cities>Zonas de actuación</template>
        </accordion-vuelidate>
        <div class="py-2 py-md-5"></div>
      </div>
    </div>
  </div>
</template>

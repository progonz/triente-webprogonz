<script lang="ts"
        src="./Register03.ts"/>
<style lang="scss">@import "Register03";</style>
<template>
  <div class="Register03 container">

    <div class="py-2 py-md-5"></div>
    <div class="row ">
      <div class="col-6 hidden-xs">
        <div style="max-width: 330px">
          <div class="fs-2 ">¿Quién será el administrador de la cuenta?</div>
          <div class="py-3">Necesitamos que te registres como administrador para que puedas gestionar la cuenta de tu
            empresa.
          </div>

        </div>
      </div>
      <div class="col-12 col-md-6">
        <div class="fs-3 pb-3"> Datos del administrador</div>

        <ui-text label="Email"
                 id="email"
                 :model-value="form.email"
                 :vuelidate="v$.form?.email"
                 @update:model-value="form.email = $event"
                 placeholder="marguis@correo.com"/>

        <ui-text label="Nombre"
                 id="name"
                 :model-value="form.name"
                 :vuelidate="v$.form?.name"
                 @update:model-value="form.name = $event"
                 placeholder="Marguis"/>

        <ui-text label="Apellidos"
                 id="lastname"
                 :model-value="form.lastname"
                 :vuelidate="v$.form?.lastname"
                 @update:model-value="form.lastname = $event"
                 placeholder="Navarro Albalat"/>

        <ui-text label="Contraseña"
                 id="password"
                 v-if="!isLogged"
                 :model-value="form.password"
                 :vuelidate="v$.form?.password"
                 type="passwords"
                 @update:model-value="form.password = $event"
                 placeholder="************"/>
        <ui-text label="Repetir Contraseña"
                 type="password"
                 :model-value="form.confirmPass"
                 :vuelidate="v$.form.confirmPass"
                 @update:model-value="form.confirmPass = $event"
                 placeholder="************"/>

        <button type="button"
                @click="onRegister()"
                class="btn btn-primary  mt-5 ">
          Guardar y finalizar
        </button>
        <div class="py-5"></div>
      </div>
    </div>
  </div>
</template>

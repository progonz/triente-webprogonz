<script lang="ts"
        src="./ResultsCatalogView.ts"/>
<style lang="scss">@import "ResultsCatalogView";</style>
<template>
  <div class="card-results">
    <header class=" d-flex justify-content-end align-items-end">
      <div class="container">
        <span role="button" @click="removeActivity()">Todas las empresas</span>
        <span class="fw-bold" v-if="activitySelected"> / {{ activitySelected.name }}</span>
        <searcher :key="componentKey"/>
      </div>
    </header>
    <section class="container my-4"
             id="count-result">
      <div class="results d-flex justify-content-between justify-content-center  align-self-center flex-column-sm ">
        <div class="py-2 ">{{ total ?? 0 }} resultados
          <span class="text-cement-gray">en {{ startTime }} seg</span>
        </div>
        <div class="d-flex align-items-center filter-by">
          <div class="text-cement-gray">Ordernar por:</div>
          <div class="d-flex justify-content-center align-items-center">
            <ui-select :options="orderBy"
                       :offSearchable="true"
                       class="ms-4"
                       @update:model-value="fetchData({order:`[${$event.value}]`})"
                       style="width: 180px"
                       :key-value="{value:'value', key: 'label'}"/>
          </div>
        </div>
      </div>
    </section>
    <section class="container position-relative">

      <EmptyResult v-if="!isLoading && companies.length === 0"/>
      <div v-for="(company, index) in companies"
           :key="index">
        <card-company :company="company" class="mb-4  animate__animated animate__zoomInUp"/>
        <banner-add-company v-if="(index%2===0|| companies.length === 1) && !existCompany"
                            class="mb-4"/>
      </div>
      <ui-loading v-if="isLoading"></ui-loading>
      <div class="py-3"></div>
      <banner-limited class="mt-3"/>
    </section>
  </div>
</template>


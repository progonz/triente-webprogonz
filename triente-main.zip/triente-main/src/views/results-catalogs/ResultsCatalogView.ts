import { Options, Vue } from 'vue-class-component';
import Searcher from '@/components/smarts/searcher/Searcher.vue';
import UiSelect from '@/components/form/ui-select/UiSelect.vue';
import CardCompany from '@/components/smarts/company/card-company/CardCompany.vue';
import BannerLimited from '@/components/smarts/banner-limited/BannerLimited.vue';
import BannerAddCompany from '@/components/smarts/banner-add-company/BannerAddCompany.vue';
import EmptyResult from '@/components/smarts/empty-result/EmptyResult.vue';
import { ICompany } from '@/models/company.model';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import UiLoading from '@/components/layout/ui-loading/UiLoading.vue';
import IActivity from '@/models/activity.model';

@Options({
  components: {
    Searcher,
    UiSelect,
    CardCompany,
    BannerLimited,
    BannerAddCompany,
    EmptyResult,
    UiLoading
  },
})
export default class ResultsCatalogView extends Vue {

  store = useStore<StateInterface>();
  timer;
  filters = null;
  private beforeNextPage = 0;
  startTime = 0;
  componentKey = 0;

  async mounted(): Promise<void> {
    window.scrollTo(0, 0);
    window.addEventListener('scroll', this.scrolling);
    this.store.watch(
      (_: StateInterface) => this.store.getters['companies/filterActive'],
      (_) => {
        this.store.commit('companies/clear');
        window.scrollTo(0, 0);
        this.fetchData();
      },
      {
        deep: true
      }
    );
  }

  get activitySelected(): IActivity {
    return this.store.getters['activities/getSelected'];
  }

  orderBy = [
    { label: 'Nombre ↑', value: 'name:asc' },
    { label: 'Nombre ↓', value: 'name:desc' },
    { label: 'Ubicación ↑', value: 'city:asc' },
    { label: 'Ubicación ↓', value: 'city:desc' },
    { label: 'Importe ↑', value: 'budget:asc' },
    { label: 'Importe ↓', value: 'budget:desc' },
    { label: 'Actividad ↑', value: 'activities:asc' },
    { label: 'Actividad ↓', value: 'activities:desc' },
    { label: 'Empleados ↑', value: 'employees:asc' },
    { label: 'Empleados ↓', value: 'employees:desc' },
  ];

  async fetchData(params = {}): Promise<void> {
    let time = new Date().getTime();

    let queryParams = { ...this.$route.query, ...(params ?? {}) };

    if (this.filterActive) {
      queryParams = { ...queryParams, filter: [this.filterActive] };
    }

    await this.store.dispatch('companies/getAll', queryParams);
    time = new Date().getTime() - time;
    this.startTime = Number((time / 1000).toFixed(1));
  }

  unmounted(): void {
    window.removeEventListener('scroll', this.scrolling);
  }

  get companies(): ICompany[] {
    return this.store.getters['companies/items'];
  }

  get total(): number {
    return this.store.getters['companies/total'];
  }

  get isLoading(): boolean {
    return this.store.getters['companies/isLoading'] == true;
  }


  get nextPage(): number {
    return this.store.getters['companies/nextPage'];
  }

  beforeMount(): void {
    this.fetchData();
  }

  get existCompany(): boolean {
    return this.store.getters['profile/getCompany']?.id !== null;
  }

  scrolling({ target }): void {
    const { scrollingElement } = target;
    const gap = 1;
    const total = scrollingElement.scrollTop + scrollingElement.clientHeight + gap;
    if (total > scrollingElement.scrollHeight) {
      if (this.timer)
        clearTimeout(this.timer);
      if (this.beforeNextPage === this.nextPage) return;
      this.beforeNextPage = this.nextPage;
      this.timer = setTimeout(() => this.fetchData({ page: this.nextPage ?? 0 }), 500);
    }
  }

  get filterActive(): any {
    return this.store.getters['companies/filterActive'];
  }

  removeActivity(): void {
    const newFilter = this.filterActive;
    delete newFilter.provinceName;
    delete newFilter.parent;
    delete newFilter.activities;
    this.store.dispatch('activities/select', null);
    this.store.dispatch('sub_activities/select', null);
    this.store.dispatch('companies/saveFilter', { ...this.filterActive, activities: [] });
    this.componentKey += 1;
  }


}

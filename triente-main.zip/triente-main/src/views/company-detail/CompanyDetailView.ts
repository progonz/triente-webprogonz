import { Options, Vue } from 'vue-class-component';
import AreaAmountCompany from '@/components/smarts/company/area-company/AreaAmountCompany.vue';
import ListTags from '@/components/smarts/list-tags/ListTags.vue';
import CardProject from '@/components/smarts/card-project/CardProject.vue';
import BannerLimited from '@/components/smarts/banner-limited/BannerLimited.vue';
import ContactCompany from '@/components/smarts/contact-company/ContactCompany.vue';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import { ICompany } from '@/models/company.model';
import UiLoading from '@/components/layout/ui-loading/UiLoading.vue';

@Options({
  components: {
    AreaAmountCompany,
    ListTags,
    CardProject,
    BannerLimited,
    ContactCompany,
    UiLoading
  },
  props: {
    id: String
  }
})
export default class CompanyDetailView extends Vue {

  id = '';

  store = useStore<StateInterface>();


  get isLogged(): boolean {
    return this.store.getters['auth/isUserLogin'];
  }

  mounted(): void {

    window.scrollTo(0, 0);
    const { id } = this.$route.params;
    if (id)
      this.store.dispatch('companies/get', id);
    else
      this.$router.push('/');
  }

   get company(): ICompany {
   return this.store.getters['companies/selected'];
  }

  get getTags(): string[] {
    const typeTarget = Object.assign({}, this.company.type);
    const type = JSON.parse(JSON.stringify(typeTarget));
    if (type.name === "Constructora") {
      const activities = (this.company?.activities ?? []).map(e => {
        const parentTarget = Object.assign({}, e.parent);
        const parent = JSON.parse(JSON.stringify(parentTarget));
        return e.name+" ("+parent.name+")";
      });
      return [...activities];
    }
    else {
      const activities = (this.company?.activities ?? []).map(e => e.name);
      return [...activities];
    }
  }

  get isLoading(): boolean {
    return this.store.getters['companies/isLoading'] === true;
  }
}

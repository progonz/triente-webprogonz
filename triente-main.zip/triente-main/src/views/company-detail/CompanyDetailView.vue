<script lang="ts"
        src="./CompanyDetailView.ts"/>
<style lang="scss">@import "CompanyDetailView";</style>

<template>
  <div class="CompanyDetail">

    <div class="container">
      <ui-loading v-if="isLoading || !(company?.id)"></ui-loading>
      <div class="row m-0 p-0 " v-else>
        <div class="bg-white col-12 col-md-8 "
             :class="{'offset-2': !isLogged,'m-0 p-0 ': isLogged }">
          <div id="company-picture">

            <img :src="company.photo.url"
                 v-if="company?.photo?.url"
                 class="img-cover  "
                 alt="company-photo">
            <div v-else class="img-cover__no-image">
              <span class="icon-fi_image  text-center "></span>

            </div>

            <img class="img-cover logo-company"
                 v-if="company?.logo?.url"
                 :src="company?.logo.url"
                 :alt="'logo '+ company?.name">
            <span v-else class="logo-company icon-fi_image  text-center image-logo-not-found d-flex justify-content-center align-items-center"></span>
          </div>
          <div class="info-company">
            <header class="fs-2">{{ company.name }}</header>
            <div class="fs-5 text-cement-gray">{{ company.description }}</div>
            <list-tags :tagsString="getTags" childClass="mt-4"/>
          </div>
          <div class="CompanyDetail_area p-3 w-100  ">
            <area-amount-company :company="company"/>
          </div>
          <div class="info-company">
            <div class="row justify-content-center">
              <div class="col-12 col-md-6">
                <header class="fs-3 ">Datos de la empresa</header>
                <div class="text-cement-gray mb-2"><strong>CIF:</strong> {{ company.cif }}</div>
                <header class="fs-3 ">Web</header>
                <div>
                  <ul class="company-networks">
                    <li>
                      <a v-if="company?.contact.website" :href="company?.contact.website" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_globe text-cement-gray"></a>
                    </li> 
                    <li v-for="(item, index) in company?.networks" :key="index">
                      <a v-if="item.name == 'web'" :href="item.url" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_globe text-cement-gray"></a>
                      <a v-if="item.name == 'linkedin'" :href="item.url" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_linkedin text-cement-gray"></a>
                      <a v-if="item.name == 'instagram'" :href="item.url" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_instagram text-cement-gray"></a>
                      <a v-if="item.name == 'facebook'" :href="item.url" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_facebook text-cement-gray"></a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-12 col-md-6">
                <header class="fs-3 ">Ubicación</header>
                <div class="text-cement-gray mb-2">{{ company.address.address }}, {{ company.address.city }}</div>
                <div class="text-cement-gray mb-2">{{ company.address.zipcode }}, {{ company.address.province }}, {{ company.address.country }}</div>
              </div>
            </div>
          </div>
          <div class="info-company">
            <header class="fs-3 ">Zonas de actuación</header>
            <div class="mb-2 d-inline-block align-items-center "
                 v-for="(perf, index) in company.cities"
                 :key="'perf-'+ index">
              <div class="lightgrey py-2 px-3 me-2 d-inline-block" >{{ perf.province }}</div>
            </div>

          </div>
          <div class="info-company" v-if="company.buildings.length">
            <header class="fs-3 ">Tipos de edificio</header>
            <div class="d-flex flex-wrap">
              <div class="lightgrey py-2 px-3 me-2 mb-2"
                   v-for="(perf, index) in company.buildings"
                   :key="'perf-'+ index">{{ perf.name }}
              </div>
            </div>


          </div>
          <!--          <div class="info-company">-->
          <!--            <header class="fs-3 ">Proyectos</header>-->
          <!--            <div class="row ">-->
          <!--              <div class="col-12 col-md-6 m-0 p-0"-->
          <!--                   v-for="prject in company.projects "-->
          <!--                   :key="prject.name">-->
          <!--                <CardProject :header="prject.name"-->
          <!--                             :picture="prject.picture"-->
          <!--                             :description="company.description"/>-->
          <!--                <ListTags :tagsString="prject.tags"-->
          <!--                          :maxTags="1"/>-->
          <!--              </div>-->
          <!--            </div>-->


          <!--          </div>-->
          <!--          <div class="info-company">-->
          <!--            <header class="fs-3 ">Valoraciones</header>-->
          <!--            <div class="row">-->
          <!--              <div class="col-12 col-md-6  px-2 pb-5 "-->
          <!--                   v-for="(rating, index) in company.ratings "-->
          <!--                   :key="'rating-'+index">-->

          <!--                <aside class="rating px-5 pt-4">-->
          <!--                  <div class=" text-cement-gray d-flex align-items-center">-->
          <!--                    <span class="rating_rating py-2 px-3 d-flex">-->
          <!--                      <span class="inner-circle me-2"></span>-->

          <!--                      {{ rating.ranking }} / 5-->
          <!--                    </span>-->
          <!--                  </div>-->
          <!--                  <div class="pt-4">{{ rating.message }}</div>-->
          <!--                  <div class="py-4 text-cement-gray">{{ rating.username }}</div>-->
          <!--                </aside>-->
          <!--              </div>-->
          <!--            </div>-->


          <!--          </div>-->
        </div>

        <div class="col-12 col-md-4 m-0 p-0 b-top-lightgrey"
             id="contact_company">

          <contact-company class="bg-white"
                           :idCompany="company.id"
                           :contact="company.contact"/>
        </div>
      </div>
      <banner-limited class="hidden-xs"/>

    </div>
  </div>

</template>


<script lang="ts" src="./ResetPwdView.ts"></script>
<style lang="scss">@import "ResetPwdView";</style>
<template>
  <auth-container>
    <template v-slot:left>
      <div class="fs-1">Crea tu nueva contraseña</div>
      <div class="py-2">Recuerda que debe tener mínimo ocho(8) caracteres, una letra mayúscula y 5 minúscula</div>

    </template>
    <template v-slot:right>
      <div
          class="d-flex flex-column ">
        <div class="px-4 px-md-5">
          <div class="fs-1 py-4"> Nueva contraseña</div>
          <ui-text label="Contraseña"
                   :model-value="form.password"
                   :vuelidate="v$.form.password"
                   type="password"
                   @update:model-value="form.password = $event"
                   placeholder="************"/>
          <ui-text label="Repetir Contraseña"
                   type="password"
                   :model-value="form.confirmPass"
                   :vuelidate="v$.form.confirmPass"
                   @update:model-value="form.confirmPass = $event"
                   placeholder="************"/>

        </div>
        <div class="py-2 small" v-if="v$.form.password.$invalid">La contraseña debe tener mínimo ocho(8) caracteres, una letra mayúscula y 5 minúscula</div>

        <div class="py-3"></div>
        <button type="button"
                @click="onRegister()"
                class="btn  mt-3 btn-primary w-100  ">
          Crear nueva contraseña
        </button>
      </div>

    </template>
  </auth-container>
</template>



import { Options, Vue } from 'vue-class-component';
import UiText from '@/components/form/ui-text/UiText.vue';
import AuthContainer from '@/components/smarts/auth-container/AuthContainer.vue';
import { required } from '@vuelidate/validators';
import { validateEqual, validateRegexEmail } from '@/helpers/validate';
import useVuelidate from '@vuelidate/core';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import toast from '@/plugins/toast.plugin';

@Options({
  components: {
    UiText,
    AuthContainer
  },
  validations: {
    form: {
      password: { required, validateRegexEmail },
      confirmPass: { required, validateEqual: (a, b) => validateEqual(a, b['password']) },
    }
  }
})
export default class SignInView extends Vue {
  v$: any = useVuelidate();
  store = useStore<StateInterface>();
  form = { password: '', confirmPass: '' };
  token = '';

  async onRegister(): Promise<void> {
    const result = await this.v$.$validate();
    if ( !result) return;
    const response = await this.store.dispatch('auth/passwordUpdate',
      { token: this.token, password: this.form.password });

    if (response) {
      toast.success('Su contraseña fue cambiada con exito, ya puede iniciar sesión');
      await this.$router.push('/sign-in');
    }
  }

  mounted(): void {
    this.token = this.$route.params.token.toString();
    if ( !this.token) {
      this.$router.push('/sign-in');

      toast.error(
        'La URL de recuperar contraseña es inválida, vuelva a solicitar una nueva a través de olvido su contraseña');
    }

  }
}

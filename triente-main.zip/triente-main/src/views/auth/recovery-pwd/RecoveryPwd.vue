<script lang="ts"
        src="./RecoveryPwd.ts"/>
<style lang="scss">@import "RecoveryPwd";</style>
<template>
  <ui-dialog :id="'recovery-pwd'"
             @onClosed="resetForm()">
    <template v-slot:dialog-actions>
      <div class="small">¿Has olvidado la contraseña?</div>
    </template>
    <template v-slot:dialog-header>Recuperar contraseña</template>
    <template v-slot:dialog-content>
      <div class="p-4">
        <div v-if="!isEmailSent">
          <p>Introduce el correo electrónico con el que creaste tu cuenta. Te enviaremos un correo con las instrucciones para recuperar tu contraseña.</p>

          <ui-text label="Email"
                   id="email"
                   :model-value="email"
                   :vuelidate="v$.email"
                   @update:model-value="email = $event"
                   placeholder="marguis@correo.com"/>

        </div>
        <div v-else>
          <img src="~@/assets/images/mail.png"
               alt="email-sent"/>
          <div class="fs-4">¡Revisa tu correo!</div>
          <p>Sigue las instrucciones para recuperar tu contraseña.</p>
        </div>
      </div>

    </template>
    <template v-slot:dialog-footer
              v-if="!isEmailSent">
      <button class="btn btn-primary "
              @click="onSubmit()">Recuperar contraseña
      </button>
    </template>
  </ui-dialog>

</template>



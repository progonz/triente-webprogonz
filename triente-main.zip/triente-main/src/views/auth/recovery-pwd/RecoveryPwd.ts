import {Options, Vue} from 'vue-class-component';
import UiText from "@/components/form/ui-text/UiText.vue";
import AuthContainer from "@/components/smarts/auth-container/AuthContainer.vue";
import {useStore} from "vuex";
import {StateInterface} from "@/store";
import {email, required} from "@vuelidate/validators";
import useVuelidate from "@vuelidate/core";
import UiDialog from "@/components/layout/ui-dialog/UiDialog.vue";


@Options({
    components: {
        UiText,
        AuthContainer,
        UiDialog
    },
    validations: {
        email: {
            required,
            email
        }
    }
})
export default class RecoveryPwd extends Vue {
    isEmailSent = false;
    v$: any = useVuelidate();
    store = useStore<StateInterface>();

    email = ''

    async onSubmit(): Promise<void> {
        const result = await this.v$.$validate()
        if (!result) return
        this.isEmailSent = await this.store.dispatch("auth/recoveryPwd", this.email)
    }

    resetForm(): void {
        this.isEmailSent = false;
        this.email = '';
        this.v$.$reset();
    }
}

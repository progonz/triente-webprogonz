<script lang="ts"
        src="./SignInView.ts"/>
<style lang="scss">@import "SignInView";</style>
<template>
  <auth-container class="SignIn">
    <template v-slot:left>
      <div class="fs-1 fw-bold">
        Siempre nos alegra verte de nuevo por aquí
      </div>
    </template>
    <template v-slot:right>
      <div
          class="d-flex flex-column">
        <div class="px-4 px-md-5">
          <div class="fs-1 py-4">Iniciar sesión</div>

          <ui-text label="Email"
                   :model-value="form.email"
                   @keydown.enter="onLogin"
                   :vuelidate="v$.form.email"
                   @update:model-value="form.email = $event"
                   placeholder="example@example.com"/>

          <ui-text label="Contraseña"
                   :model-value="form.password"
                   @keydown.enter="onLogin"
                   :vuelidate="v$.form.password"
                   type="password"
                   @update:model-value="form.password = $event"
                   placeholder="************"/>

          <recovery-pwd/>

        </div>
        <button type="button"
                @click="onLogin()"
                class="btn  mt-3 btn-primary w-100  ">
          Iniciar sesión
        </button>


        <div id="container-forgot-password"
             class="muted py-3 px-md-5 d-flex justify-content-around mt-2"
             @click="$router.push('/register')">
          <div>¿Aún no tienes cuenta?</div>
          <div class="fw-bold">Regístrate
            <span class="icon-fi_arrow-right"></span>
          </div>
        </div>
      </div>
    </template>
  </auth-container>
</template>



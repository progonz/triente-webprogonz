import { Options, Vue } from 'vue-class-component';
import UiText from '@/components/form/ui-text/UiText.vue';
import AuthContainer from '@/components/smarts/auth-container/AuthContainer.vue';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import { email, required } from '@vuelidate/validators';
import useVuelidate from '@vuelidate/core';
import RecoveryPwd from '@/views/auth/recovery-pwd/RecoveryPwd.vue';
import isDev from '@/helpers/is-dev';


@Options({
  components: {
    UiText,
    AuthContainer,
    RecoveryPwd
  },
  validations: {
    form: {
      email: {
        required,
        email
      },
      password: { required }
    }
  }
})
export default class SignInView extends Vue {

  v$: any = useVuelidate();
  store = useStore<StateInterface>();

  form = { email: '', password: '' };

  mounted(): void {    
    if (isDev) {
      this.form = {
        email: 'guzmle2@gmail.com',
        password: 'Leonor2022*'
      };
    }
    window.scrollTo(0, 0);
  }

  async onLogin(): Promise<void> {
    const result = await this.v$.form.$validate();
    if ( !result) return;


    await this.store.dispatch('auth/login', this.form);
    if (this.store.getters['auth/isUserLogin'])
      await this.$router.push('/');
  }
}

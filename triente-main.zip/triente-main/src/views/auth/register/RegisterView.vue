<script lang="ts"
        src="./RegisterView.ts"/>
<style lang="scss">@import "RegisterView";</style>
<template>
  <auth-container>
    <template v-slot:left>
      <div class="fs-1">Regístrate en Triente</div>
      <div>Descubre Triente, la base de datos más completa de empresas del sector de la construcción de España.
        Encuentra y conecta ahora con la empresa que necesitas.
      </div>

    </template>
    <template v-slot:right>
      <div
          class="d-flex flex-column ">
        <div class="px-4 px-md-5">
          <div class="fs-1 py-4"> Crear Cuenta</div>
          <ui-text label="Nombre"
                   :model-value="form.name"
                   :vuelidate="v$.form.name"
                   @update:model-value="form.name = $event"
                   placeholder="Marguis"/>
          <ui-text label="Apellidos"
                   :model-value="form.lastname"
                   :vuelidate="v$.form.lastname"
                   @update:model-value="form.lastname = $event"
                   placeholder="Navarro Albalar"/>
          <ui-text label="Email"
                   :model-value="form.email"
                   :vuelidate="v$.form.email"
                   @update:model-value="form.email = $event"
                   placeholder="example@example.com"/>
          <ui-text label="Contraseña"
                   :model-value="form.password"
                   :vuelidate="v$.form.password"
                   type="password"
                   @update:model-value="form.password = $event"
                   placeholder="************"/>

          <ui-text label="Repetir Contraseña"
                   type="password"
                   :model-value="form.confirmPass"
                   :vuelidate="v$.form.confirmPass"
                   @update:model-value="form.confirmPass = $event"
                   placeholder="************"/>

        </div>
        <div class="d-flex justify-content-center"  v-if="form?.password && v$.form.password.$invalid">

          <div class="py-2 small text-danger text-center w-75 " style="max-width: 300px">
            La contraseña debe tener mínimo ocho(8) caracteres, una letra mayúscula y 5 minúscula
          </div>

        </div>
        <button type="button"
                @click="onRegister()"
                class="btn  mt-3 btn-primary w-100  ">
          Crear cuenta
        </button>
      </div>
      <div id="container-forgot-password"
           class="muted py-3 px-md-5 d-flex justify-content-around mt-2"
           @click="$router.push('/sign-in')">
        <div>Ya tengo una cuenta</div>
        <div class="fw-bold">Iniciar sesión
          <span class="icon-fi_arrow-right"></span>
        </div>
      </div>
    </template>
  </auth-container>
</template>



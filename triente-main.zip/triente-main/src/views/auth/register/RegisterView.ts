import { Options, Vue } from 'vue-class-component';
import UiText from '@/components/form/ui-text/UiText.vue';
import AuthContainer from '@/components/smarts/auth-container/AuthContainer.vue';
import useVuelidate from '@vuelidate/core';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import { email, required } from '@vuelidate/validators';
import { useToast } from 'vue-toastification';
import toast from '@/plugins/toast.plugin';
import { validateEqual, validateRegexEmail } from '@/helpers/validate';


@Options({
  components: {
    UiText,
    AuthContainer
  },
  validations: {
    form: {
      email: {
        required,
        email
      },
      password: { required, validateRegexEmail },
      name: { required },
      lastname: { required },
      confirmPass: { required, validateEqual: (a, b) => validateEqual(a, b['password']) },
    }
  }
})
export default class RegisterView extends Vue {
  v$: any = useVuelidate();
  store = useStore<StateInterface>();

  toast = useToast();

  form = {};

  async onRegister(): Promise<void> {
    const result = await this.v$.$validate();
    if ( !result) return;
    const response = await this.store.dispatch('auth/register', this.form);

    if (response) {
      toast.success('Registrado con exito ya puedes iniciar sesion');
      await this.$router.push('/');
    }


  }


}

<script lang="ts"
        src="./HomeView.ts"/>
<style lang="scss">@import "HomeView";</style>
<template>
  <div id="home-section">

    <main>
      <section id="discover"
               class=" img-cover d-flex flex-column  justify-content-lg-end ">
        <div class=" container ">

          <div>
            <h1 class="text-white">Discover.</h1>
            <h1 class="text-white">Decide.</h1>
            <h1 class="text-white">Connect.</h1>
          </div>
          <searcher/>
        </div>
      </section>
      <section id="number-search"
               class="container d-flex flex-column justify-content-center ">
        <h2 class=" py-5 px-2 p-md-5">Encuentra la empresa que necesitas</h2>
        <div class="row m-0">
          <div class="col-12 p-5 col-md-4">
            <div class="number-title number-one">1 /</div>
            <h5>Busca</h5>
            <span>En la base de datos más completa del sector y encuentra lo que necesitas.</span>
          </div>
          <div class="col-12 p-5 col-md-4">

            <div class="number-title number-two">2 /</div>

            <h5>Decide</h5>
            <span>Selecciona las empresas más adecuadas para tu proyeto y toma la decisión correcta.</span>
          </div>
          <div class="col-12 p-5 col-md-4">
            <div class="number-title number-three">3 /</div>

            <h5>Conecta</h5>
            <span>Establece una relación comercial de forma rápida, sin utilizar otros canales.</span>
          </div>
        </div>
      </section>
      <companies-close-me class="container"/>
      <find-companies/>
      <section id="services"
               class="container my-5">
        <p class="py-5 hidden-xs"></p>
        <div class="d-flex justify-content-between mb-5 flex-column-sm">
          <h2>Los servicios más buscados del sector de
            <br>
            la construcción están en Triente
          </h2>
          <a class="hidden-xs" @click="goAllServices()">Todos los servicios
            <span class="icon-fi_arrow-right"></span>
          </a>
        </div>
        <div class="d-flex">
          <div class="me-4 py-2"
               v-for="(c,i) in type"
               :key="i"
               @click="activeType(c)"
               role="button"
               :class="{'line-active':typeActive?.id===c.id}">{{ c.name }}               
          </div>

        </div>
        <div class="row services m-0">
          <div class="col-6 col-md-2   p-3 services-items"
               v-for="(info,i) in activities"
               :key="i">
            <div>{{ info.name }}</div>
            <div class="text-cement-gray mt-2"> {{ info.totalChildren }}</div>
          </div>
        </div>
        <a class="only-xs my-4" @click="goAllServices()">Todos los servicios
          <span class="icon-fi_arrow-right"></span>
        </a>

      </section>
      <section class="container" v-if="!isLogged">
        <banner-join/>
      </section>
      <!--      <section class="container">-->
      <!--        <f-a-qs/>-->
      <!--      </section>-->
<!--
      <section class="container">
        <quotes-slider/>
      </section>
-->
      <!--      <banner-newsletter/>-->

    </main>
  </div>
</template>


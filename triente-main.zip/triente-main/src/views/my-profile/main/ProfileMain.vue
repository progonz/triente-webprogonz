<script lang="ts"
        src="./ProfileMain.ts"/>
<style lang="scss">@import "ProfileMain";</style>
<template>
  <div class="ProfileMain bg-white mb-md-5 mx-md-5 mt-md-2">
    <div class=" anchors-menu">
      <a class="subtitle text-truncate w-50 anchor py-3 "
         @click="activeMenu = null"
         :class="!activeMenu?'active':''"
         href="#profile-admin">Administrador de la cuenta
      </a>
      <a class="subtitle text-truncate w-50 anchor py-3"
         @click="activeMenu = 'contact'"
         :class="activeMenu=== 'contact'?'active':''"
         href="#profile-update-pass">Cambiar contraseña
      </a>
    </div>
    <div class="pt-5 only-xs"></div>
    <div class="container py-5 container-mw">
      <div id="info-profile">
        <div class="fs-4 pb-3" id="profile-admin">Administrador de la cuenta</div>
        <ui-text label="Nombre"
                 :model-value="profile?.name"
                 :vuelidate="v$.profile.name"
                 @update:model-value="profile.name = $event"
                 placeholder="Marguis"/>
        <ui-text label="Apellidos"
                 :model-value="profile?.lastname"
                 :vuelidate="v$.profile.lastname"
                 @update:model-value="profile.lastname = $event"
                 placeholder="Navarro Albalat"/>
        <ui-text label="Correo Electronico"
                 :model-value="profile?.email"
                 :vuelidate="v$.profile.email"
                 @update:model-value="profile.email = $event"
                 placeholder="marguis@correo.es"/>
        <div class="p-2"></div>
        <button type="button"
                @click="saveInfo()"
                class="btn btn-primary">
          Actualizar cambios
        </button>
      </div>
      <div id="info-password"
           class="mt-5">
        <div class="fs-4 pb-3" id="profile-update-pass">Cambiar contraseña</div>
        <ui-text label="Contraseña actual"
                 :model-value="password.actual"
                 :vuelidate="v$.password.actual"
                 @update:model-value="password.actual = $event"
                 type="password"
                 placeholder="********"/>

        <ui-text label="Nueva contraseña"
                 :model-value="password.new"
                 :vuelidate="v$.password.new"
                 @update:model-value="password.new = $event"
                 type="password"
                 placeholder="********"/>
        <ui-text label="Confirmar nueva contraseña"
                 :model-value="password.confirmPass"
                 :vuelidate="v$.password.confirmPass"
                 @update:model-value="password.confirmPass = $event"
                 type="password"
                 placeholder="********"/>

        <div class="pb-3">
          <small class="text-muted lh-1">Recuerda que debe tener mínimo ocho(8) caracteres, una letra mayúscula y 5 minúscula
          </small>

        </div>
        <button type="button"
                @click="updatePassword()"
                class="btn btn-primary ">
          Actualizar cambios
        </button>
      </div>
    </div>
  </div>
</template>



<script lang="ts"
        src="./MyCompany.ts"/>
<style lang="scss">@import "MyCompany";</style>
<template>
  <div class="MyCompany bg-white mb-md-5 mx-md-5 mt-md-2">
    <div class=" anchors-menu">
      <a class="subtitle text-truncate w-50 anchor py-3 "
         @click="activeMenu = null"
         :class="!activeMenu?'active':''"
         href="#profile-info-company">Datos de la empresa
      </a>
      <a class="subtitle text-truncate w-50 anchor py-3"
         @click="activeMenu = 'contact'"
         :class="activeMenu=== 'contact'?'active':''"
         href="#profile-info-contact">Datos de contacto
      </a>
    </div>
    <div class="pt-5 only-xs"></div>
    <div class="container py-4 pb-5 container-mw" v-if="form?.id">
      <div
          id="profile-info-company">
        <div class="subtitle">Datos de la empresa</div>
        <p class="pt-3"></p>

        <company-data :form="form"
                      :vuelidate="v$.form"
                      @deleteLogo="deleteLogo()"
                      @deletePhoto="deletePhoto()"
                      @deletePicture="deletePicture()"
                      @update:form="updateChange($event)"
                      :txt-button="'Actualizar cambios'"/>

      </div>
      <div id="profile-info-contact">
        <div class="subtitle mt-4 mb-3">Datos de contacto</div>

        <company-contact
            :form="form.contact"
            :vuelidate="v$.form.contact"
            @update:form="updateChange({contact:$event})"
            :txt-button="'Actualizar cambios'"></company-contact>
      </div>
    </div>

    <ui-loading class="container py-4 pb-5 container-mw" v-else/>
  </div>
</template>



<script lang="ts"
        src="./MyProfile.ts"/>
<style lang="scss">@import "MyProfile";</style>
<template>
  <div class="MyProfile h-100 ">
    <div id="container-myprofile" class="container h-100 ">
      <div class="row h-100">
        <div class="col-3 m-0 p-0 hidden-xs">
          <ul class="mt-2">
            <li v-for="(menu, index) in menuProfile"
                :key="'menu-'+index">
              <router-link :to="menu.link"
                           exact>
                <span v-if="menu.icon"
                      class="icon  "
                      :class="menu.icon"></span>
                {{ menu.label }}
              </router-link>
            </li>
            <li @click="onLogout()">
              <a>Cerrar sesión</a>
            </li>
            <banner-add-company-v2 class="mt-md-5"
                                   v-if="!companyCreated"/>
          </ul>
        </div>
        <div class="col-12 col-md-9 m-0 p-0 ">
          <router-view></router-view>
        </div>
      </div>
    </div>
  </div>
</template>



<script lang="ts"
        src="./CompanyActivities.ts"></script>
<style lang="scss">@import "CompanyActivities";</style>
<template>
  <div class="CompanyActivities bg-white mb-md-5 mx-md-5 mt-md-2">
    <div class=" anchors-menu">
      <a class="subtitle text-truncate w-50 anchor py-3 "
         @click="activeMenu = null"
         :class="!activeMenu?'active':''"
         href="#profile-work">¿A qué se dedica?
      </a>
      <a class="subtitle text-truncate w-50 anchor py-3"
         @click="activeMenu = 'contact'"
         :class="activeMenu=== 'contact'?'active':''"
         href="#profile-actuacion">Zonas de actuación
      </a>
    </div>
    <div class="pt-5 only-xs"></div>
    <div class="container py-4 pb-5 container-mw" v-if="form?.id">
      <div class="fs-4" id="profile-work">¿A qué se dedica tu empresa?</div>
      <p class="pt-3"></p>
      <company-function
        :form="form"
        :vuelidate="v$.form"
        @update:form="updateChange($event)"
        :type="form?.type?.id"
        :txt-button="'Actualizar cambios'" />

      <div class="fs-4 pt-5" id="profile-actuacion">Zonas de actuación</div>
      <p class="pt-1"></p>
        <company-performance :form="form.cities"
          :vuelidate="v$.form.cities"
          @update:form="form.cities=$event"
          :txt-button="'Actualizar cambios'" />
      <div class="py-3"></div>

      <button type="button"
        @click="updateChange(form)"
        class="btn btn-primary"
      >
        Actualizar cambios
      </button>
    </div>
    <ui-loading class="container py-4 pb-5 container-mw" v-else></ui-loading>
  </div>
</template>

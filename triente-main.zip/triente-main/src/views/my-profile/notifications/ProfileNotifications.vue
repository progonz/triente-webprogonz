<script lang="ts"
        src="./ProfileNotifications.ts"/>
<style lang="scss">@import "ProfileNotifications";</style>
<template>

  <div class="ProfileNotifications bg-white mb-md-5 mx-md-5 mt-md-2">
    <div class="container py-5 container-mw">
      <div id="info-profile">
        <div class="fs-4">Notificaciones</div>
        <div class="fs-5 pt-4">Comunicaciones por email</div>
        <p class="py-2"></p>
        <div class="d-flex justify-content-between my-2">
          <div>Nuevos perfiles de empresa en Triente</div>
          <div class="form-check form-switch">
            <input class="form-check-input"
                   type="checkbox">
          </div>
        </div>
        <div class="d-flex justify-content-between my-2">
          <div>Visualizaciones de mi perfil</div>
          <div class="form-check form-switch">
            <input class="form-check-input"
                   type="checkbox">
          </div>
        </div>
        <div class="d-flex justify-content-between my-2">
          <div>Actualizaciones en la plataforma</div>
          <div class="form-check form-switch">
            <input class="form-check-input"
                   type="checkbox">
          </div>
        </div>
        <div class="p-2"></div>
        <button type="button"
                class="btn btn-primary">
          Actualizar cambios
        </button>
      </div>

    </div>
  </div>
</template>



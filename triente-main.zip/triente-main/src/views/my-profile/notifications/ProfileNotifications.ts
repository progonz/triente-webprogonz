import {Options, Vue} from 'vue-class-component';

@Options({})
export default class MyProfileNotifications extends Vue {


}

<script lang="ts"
        src="./UiTextArea.ts"/>
<style lang="scss">@import "UiTextArea";</style>
<template>

  <div class="mb-3 input-ui-text-area">
    <label :for="idInput"
           class="form-label">{{ label }}
    </label>
    <textarea autocomplete="off"
              style="min-height: 150px; max-height: 400px"
              :value="modelValue"
              @input="updatedEmit($event.target.value)"
              :class="{'is-invalid':vuelidate?.$silentErrors.length && vuelidate.$dirty}"
              class="form-control"
              @blur="vuelidate?.$touch()"
              :id="idInput"
              :placeholder="placeholder"/>
    <div class="invalid-feedback"
         v-for="(msj, index) in vuelidate?.$silentErrors"
         :key="'mss-'+index">
      {{ msj.$message }}
    </div>
  </div>
</template>

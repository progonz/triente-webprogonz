<script lang="ts"
        src="./UiCheckBox.ts"/>
<style lang="scss">@import "UiCheckBox";</style>
<template>
  <div class="UICheckBox  ">
    <div class="check_check-box mb-2" :class="{'active':isChecked, 'is-invalid':vuelidate?.$silentErrors.length && vuelidate.$dirty}">

      <span class="input-checked"
            :class="{'checked' : isChecked}">
        <span class="icon-fi_check"></span>
      </span>
      <span class="form-check-label ms-2 ">
        {{ label }}
      </span>
    </div>
  </div>
</template>

<script lang="ts"
        src="./UiText.ts"/>
<style lang="scss">@import "UiText";</style>
<template>

  <div class="mb-3 input-ui-text ">
    <label v-if="label" :for="idInput"
           class="form-label">{{ label }}
    </label>
    <input :type="type"
           :value="modelValue"
           @input="updatedEmit($event.target.value)"
           autocomplete="off"
           class="form-control "
           :class="{'is-invalid':vuelidate?.$silentErrors.length && vuelidate.$dirty}"
           :id="idInput"
           :disabled="disabled"
           @blur="vuelidate?.$touch()"
           :placeholder="placeholder">
    <small class="text-cement-gray"
           v-if="subLabel"> {{ subLabel }}
    </small>
    <ui-form-message :vuelidate="vuelidate"/>
  </div>
</template>

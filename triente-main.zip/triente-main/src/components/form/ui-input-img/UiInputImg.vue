<script lang="ts"
        src="./UiInputImg.ts"/>
<style lang="scss">@import "UiInputImg";</style>
<template>

  <div class="UiInputImg"
       @click="$refs.fileInput.click()">
    <div class="preview"
         v-if="url">
      <img :src="url" alt="Img bg"/>
      <button type="button"
              @click.stop="removeImg()"
              class="btn btn-light button_delete-img  btn-icon">
        <span class="icon-fi_trash text-danger  "></span>

      </button>

    </div>
    <div v-else
         class="upload-img d-flex justify-content-center align-items-center py-5 flex-column">
      <span class="icon-fi_image  text-center "></span>
      <div class=" small text-cement-gray"> Click o arrastra y suelta imagen acá</div>

    </div>
    <input type="file"
           hidden
           ref="fileInput"
           @change="imgChange">
  </div>
</template>

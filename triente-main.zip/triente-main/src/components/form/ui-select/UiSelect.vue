<script lang="ts"
  src="./UiSelectType.ts"></script>
<style lang="scss">@import "UiSelect";</style>
<style src="vue-multiselect/dist/vue-multiselect.css"></style>

<template>
  <a class=" ui-select">
    <label v-if="label" class="form-label">{{ label }}</label>
    <vue-multiselect
      :limit="99999"
      v-if="!(keyValue && keyValue.value)"
      v-model="txtValue"
      :internal-search="false"
      :options="(urlApi?optionsApi:(listFilter.length?listFilter:options))??[]"
      :multiple="multiple === true"
      :disabled="disabled"
      :searchable="!offSearchable "
      @search-change="asyncFind"
      @select="onSelected"
      @remove="onChange"
      :close-on-select="true"
      :max="multiple?3:null"
      select-label=""
      :deselect-label="'-'"
      :showNoResults="false"
      :selected-label="'✓'"
      :loading="isLoading"
      :placeholder="placeholder??label"
    >
      <template v-slot:noResult>
        <span>
          No encontrado
        </span>
      </template>
    </vue-multiselect>
    <vue-multiselect
      :internal-search="false"
      v-if="keyValue && keyValue.value"
      v-model="txtValue"
      :options="(urlApi?optionsApi:(listFilter.length?listFilter:options))??[]"
      :disabled="disabled"
      :showNoResults="false"
      :loading="isLoading"
      @remove="onChange"
      @search-change="asyncFind"
      :multiple="multiple ===true"
      :close-on-select="true"
      @select="onSelected"
      :searchable="!offSearchable "
      select-label=""
      :selected-label="'✓'"
      :deselect-label="'-'"
      :limit="99999"
      :placeholder="placeholder??label??'Complete para buscar'"
      :label="keyValue?.key"
      :track-by="keyValue?.value"
    >
      <template v-slot:noResult>
        <span>
          No encontrado
        </span>
      </template>
    </vue-multiselect>
    <ui-form-message :vuelidate="vuelidate"/>
  </a>
</template>

<script lang="ts"
        src="./UiFormMessage.ts"/>
<style lang="scss">@import "UiFormMessage";</style>
<template>

  <div v-if="vuelidate === undefined"
       class="UiFormMessage invalid-feedback"
       :style="{'display': isShow && message?'block':'none'}">
    {{ message }}
  </div>
  <div v-else>
    <div class="invalid-feedback"
         :style="{'display': vuelidate.$silentErrors.length && vuelidate.$dirty?'block':'none'}"
         v-for="(msj, index) in vuelidate.$silentErrors"
         :key="'mss-'+index">
      {{ msj.$message }}
    </div>
  </div>

</template>

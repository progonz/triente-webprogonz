<script lang="ts"
        src="./CompaniesCloseMe.ts"/>
<style lang="scss">@import "CompaniesCloseMe";</style>
<template>
  <div class="companies-close-me   ">
    <h2 class="m-5">Descubre empresas
      <br>
      cerca de ti
    </h2>
    <div class="m-5 cities">
      <a class="city"
         :class="{'active': JSON.stringify(city) === JSON.stringify(cityActive)}"
         v-for="city in cities"
         :key="city"
         @click="onActiveCity(city)">
        {{ city.province }}
      </a>
      <a class="city"
           @click="goTo({clear:true})">
        Otras
      </a>
    </div>
    <div class="m-5 d-flex align-self-stretch row flex-nowrap "
         id="companies">
      <a class="col  "
         v-for="company in companies"
         :key="company.name">
        <card-project :header="company.name"
                      @click="$router.push('/company/'+ company?.id)"
                      :picture="company.photo?.url"
                      :logo="company.photo?.url"
                      :description="company.description"/>
      </a>

      <div class="col company  m-0 p-0 position-relative  d-flex flex-column justify-content-around" :style="{maxWidth:'25vw'}">
        <img class="company_img w-100"
             src="~@/assets/images/triangles-companies.png"
             alt="">

        <div class="bg-multi-points img-cover position-absolute w-100 h-100 top-0"></div>
        <div class="white-triangle"></div>


        <a class="d-flex justify-content-around h2" @click="goTo({clear:false})">
          <span>Ver
            <br>
            todas
          </span>
          <span
              class="icon-fi_arrow-right"></span>
        </a>
      </div>
    </div>

  </div>
</template>

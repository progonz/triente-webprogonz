import { Options, Vue } from 'vue-class-component';
import CardProject from '@/components/smarts/card-project/CardProject.vue';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import { IPaginate } from '@/models/paginate.model';
import cities from '@/store/utils/cities';
import { ICompany } from '@/models/company.model';
import Cities from '@/store/utils/cities';
import { IAddress } from '@/models/address.model';
import UrlApi from '@/models/url-api.model';
import api from '@/store/api';
import provinces from '@/store/utils/provinces';
import { ref } from 'vue';

@Options({
  components: {
    CardProject
  },
})
export default class CompaniesCloseMe extends Vue {

  citiesValid = [
    'Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Bilbao', 'Zaragoza'
  ];
  store = useStore<StateInterface>();
  private cityActive?: IAddress = null;
  companies: ICompany[] = [];
  cities: IAddress[] = [];

  async getCompanies(city: IAddress): Promise<void> {
    const retorno = await this.store.dispatch('companies/getBy', { perPage: 4, cityName: city.province });
    this.companies = retorno.items ?? [];
  }

  mounted(): void {
    this.store.watch(
      (_: StateInterface) => this.store.getters['provinces/getItems'],
      (_: IAddress[]) => this.loadCities(),
      {
        deep: true
      }
    );
    this.loadCities();
  }

  loadCities(): void {
    this.cities = this.store.getters['provinces/getItems'].filter((address: IAddress) => {
      return this.citiesValid.filter(e => address.province.toLowerCase() == e.toLowerCase()).length > 0;
    });
    if ( !this.cityActive && this.cities.length)
      this.getCompanies(this.cities[0]);
  }

  onActiveCity(value: IAddress): void {
    this.cityActive = value;
    this.getCompanies(value);
  }


  goTo({ clear = false }: { clear?: boolean }): void {
    this.store.dispatch('companies/saveFilter',
      clear
        ? {}
        : { city: this.cityActive });
    this.$router.push('/companies');
  }


}

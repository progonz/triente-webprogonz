<script lang="ts"
        src="./ContactCompany.ts"/>
<style lang="scss">@import "ContactCompany";</style>
<template>
  <div class="ContactCompany " v-if="isLogged">

    <div class="b-bottom-lightgrey b-right-lightgrey">
      <div v-if="isSend"
           class="d-flex justify-content-center align-items-center flex-column p-4">
        <img src="~@/assets/images/mail.png"
             alt="email-sent">
        <div class="fs-3">¡Mensaje enviado!</div>
        <div class="text-center">Acabas de contactar con Fernández Molina, en breve se pondrá en contacto contigo.</div>
      </div>
      <div v-if="!isSend"
           class=" p-3 "
           :class="{'box-contact':!isContact, 'bg-grey':!isContact && !isSend}">
        <div class="fs-3">Contacta con la empresa</div>
        <div class="mt-3">Rellena el formulario y avisaremos a Fernández Molina para que se ponga en contacto contigo
        </div>

        <div id="form-contact"
             class="pt-3"
             v-if="isContact">
          <ui-text label="Nombre"
                   :model-value="form.name"
                   :vuelidate="v$.form.name"
                   @update:model-value="form.name = $event"
                   id="name"
                   placeholder="Marguis"/>
          <ui-text label="Email"
                   :model-value="form.email"
                   :vuelidate="v$.form.email"
                   @update:model-value="form.email = $event"
                   id="email"
                   placeholder="example@example.com"/>
          <ui-text label="Teléfono"

                   :model-value="form.phone"
                   :vuelidate="v$.form.phone"
                   @update:model-value="form.phone = $event"
                   id="tlf"
                   placeholder="666 666 666"/>
          <ui-text-area id="message"
                        :model-value="form.message"
                        :vuelidate="v$.form.message"
                        @update:model-value="form.message = $event"
                        label="Tu mensaje"/>

          <ui-check-box
              :is-checked="form.policy"
              @click="form.policy = !form.policy"
              :vuelidate="v$.form.policy" :label="''"/>
          <a href="/pdf/Politica.pdf" target="_blank">
            Aceptar política de privacidad
          </a>
<!--
          <ui-check-box
              :is-checked="form.allow_notifications"
              @click="form.allow_notifications = !form.allow_notifications"
              :vuelidate="v$.form.allow_notifications" :label="'Recibir altas de empresas similares a esta'"/>
-->
        </div>
        <button type="button"
                @click="toggleContact()"
                class="mt-5 btn btn-primary w-100 btn-icon btn-h64">
          Contactar
          <span class="icon-fi_arrow-up-right px-3"></span>
        </button>
      </div>
      <div v-if="!isContact && !isSend">

        <div class="d-flex align-items-center my-4 ms-3">
          <span class="me-3 fs-4">
            <svg version="1.1" 
              xmlns="http://www.w3.org/2000/svg" 
              xmlns:xlink="http://www.w3.org/1999/xlink" 
              width="20" height="20" viewBox="0 0 20 20">
              <path fill="#000000" d="M11 10c-1 1-1 2-2 2s-2-1-3-2-2-2-2-3 1-1 2-2-2-4-3-4-3 3-3 3c0 2 2.055 6.055 4 8s6 4 8 4c0 0 3-2 3-3s-3-4-4-3z"></path>
            </svg>
          </span>
          {{ contact?.phone }}
        </div>
<!--        <div class="d-flex align-items-center ms-3 my-4">-->
<!--          <span class="icon-fi_mail me-3 fs-4"></span>-->
<!--          {{ contact?.email }}-->
<!--        </div>-->
      </div>
    </div>
  </div>
</template>

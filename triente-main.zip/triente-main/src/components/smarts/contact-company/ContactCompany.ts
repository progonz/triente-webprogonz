import { Options, Vue } from 'vue-class-component';
import UiText from '@/components/form/ui-text/UiText.vue';
import UiTextArea from '@/components/form/ui-textarea/UiTextArea.vue';
import UiCheckBox from '@/components/form/ui-checkbox/UiCheckBox.vue';
import { useStore } from 'vuex';
import { StateInterface } from '@/store';
import { ICompany } from '@/models/company.model';
import useVuelidate from '@vuelidate/core';
import { email, required, sameAs } from '@vuelidate/validators';
import toast from '@/plugins/toast.plugin';

@Options({
  components: {
    UiText,
    UiTextArea,
    UiCheckBox
  },
  props: {
    idCompany: String,
    contact: Object
  },
  validations: {
    form: {
      email: {
        required,
        email
      },
      message: { required },
      phone: { required },
      name: { required },
      policy: {
        sameAs: sameAs(true)
      },
    }
  }
})
export default class ContactCompany extends Vue {
  v$: any = useVuelidate();
  store = useStore<StateInterface>();
  contact: ICompany;
  idCompany: string;
  isContact = false;
  isSend = false;
  // form = {
  //   email: '',
  //   name: '',
  //   message: '',
  //   phone: '',
  //   allow_notifications: false,
  //   policy: false
  // };
  form = {
    email: '',
    name: '',
    message: '',
    phone: '',
    policy: false
  };

  async toggleContact(): Promise<void> {
    if (this.isContact)
      this.isSend = await this.sendEmail();
    else
      this.isContact = !this.isContact;
  }

  get isLogged(): boolean {
    return this.store.getters['auth/isUserLogin'];
  }

  async sendEmail(): Promise<boolean> {   
    const result = await this.v$.form.$validate();
    if ( !result) return false;
    const payload = this.form;
    delete payload.policy;
    this.isSend = await this.store.dispatch('companies/contact', { id: this.idCompany, contact: payload });
    if (this.isSend)
      toast.success('Mensaje enviado.');
    this.isContact = false;
  }
}

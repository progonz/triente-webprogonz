<script lang="ts"
        src="./DialogAdvancedSearch.ts"/>
<style lang="scss">@import "DialogAdvancedSearch";</style>
<template>
  <div class="DialogAdvancedSearch">
    <div
        data-bs-toggle="modal"
        data-bs-target="#idAdvanceSearch">
      <slot></slot>
    </div>

    <!-- Modal -->
    <div class="modal fade "
         id="idAdvanceSearch"
         data-bs-backdrop="static"
         data-bs-keyboard="false"
         tabindex="-1"
         aria-labelledby="advancedSearch"
         aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title"
                id="advanceSearch">1.234 empresas
            </h5>
            <button type="button"
                    @click="resetForm()"
                    class="btn btn_close_dialog p-2"
                    data-bs-dismiss="modal"
                    aria-label="Close">
              <span class="icon-fi_x"></span>
            </button>

          </div>
          <div class="modal-body m-0 p-0">
            <div v-if="isLoading"
                 class="d-flex flex-column justify-content-center align-items-center">
              <div class="fs-5 px-5 py-2">
                Espera un segunda mientras buscamos las empresas más adecuadas para ti
              </div>
              <ui-loading></ui-loading>
              <div>Afinando las mejores coincidencias...</div>
              <p class="py-4"></p>
              <div class="d-flex align-items-center justify-content-end gap-5 w-100">
                <a
                    id="close-form-search"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    @click="resetForm()"> Cerrar
                </a>
                <button class="btn triente-yellow py-4 px-4 fw-bold btn-h64"
                        @click="resetForm()">
                  Volver a empezar
                </button>
              </div>
            </div>
            <accordion-vuelidate ref="accompany"
                                 v-if="!isLoading"
                                 :sections="['need','budget', 'address', 'employees', 'area']"
                                 :enable-back="true"
                                 :show-line-position="true"
                                 :vuelidate="v$.form"
                                 @finished="onFinished()">
              <template v-slot:form-need>
                <div class="px-3 py-2">
                  <div class="subtitle pb-3">¿Qué necesitas?</div>
                  <div class="d-flex  flex-column-sm flex-wrap">

                    <ui-check-box :label="'Necesito un '+type.name"
                                  v-for="(type, index) in typeCompany"
                                  :key="'type-'+index"
                                  class="h-100 d-flex align-items-center justify-content-md-center check-box w-sm-100"
                                  @click="updateType(type)"
                                  :is-checked="type.id === form.need.type"
                                  :value=" type.id"/>
                  </div>
                  <ui-form-message class="mb-2"
                                   :vuelidate="v$.form.need.type"/>

                  <div class="subtitle py-4">¿Qué actividad necesitas que haga?</div>
                  <ui-select
                    :options="activities"
                    @update:model-value="form.need.activity = $event"
                    :model-value="form.need.activity"
                    :disabled="!form.need.type"
                    :queryParams="{main:true, companyType:form.need.type}"
                    :vuelidate="v$?.form.need.activity"
                    :key-value="{key:'name', value: 'id'}"
                  />
                  <div class="subtitle py-4"> ¿Buscas algo más concreto?</div>
                  <div class="small text-cement-gray pb-3">Selecciona una actividad para poder completar este campo
                  </div>
                  <ui-select
                    :urlApi="urlApi.ACTIVITIES"
                    :disabled="!form.need.activity"
                    @update:model-value="form.need.subActivity = $event"
                    :model-value="form.need.subActivity"
                    :queryParams="{main:false, type:form.need.type, parent:form.need.activity['id']}"
                    :vuelidate="v$?.form?.need?.subActivity"
                    :key-value="{key:'name', value: 'id'}"
                  />
                </div>

              </template>
              <template v-slot:form-budget>
                <div class="px-3 py-2">
                  <div class="subtitle pb-3">¿En qué rangos de presupuesto te mueves?</div>
                  <div v-for="(type, index) in typeRange"
                       :key="'type-'+index">
                    <ui-check-box :label="(type?.min=== 0 && type?.max===0)?'No hay presupuesto cerrado':type.max?(formatBudget(type.min)+'-'+formatBudget(type.max)+'€'):('+'+formatBudget(type.min)+'€') "
                                  class="check-box"
                                  @click="form['budget'] = type"
                                  :is-checked="JSON.stringify(type) === JSON.stringify(form.budget)"
                                  :value=" type"/>

                  </div>


                  <ui-form-message class="mb-2"
                                   :vuelidate="v$.form.budget"/>
                </div>
              </template>
              <template v-slot:form-address>
                <div class="px-3 py-2">
                  <div class="subtitle pb-3">¿Dónde debería operar la empresa que busca?</div>
                  <div>Ubicación</div>
                  <ui-select :urlApi="urlApi.PROVINCES"
                             @update:model-value="form.city = $event"
                             :model-value="form.city"
                             :vuelidate="v$?.form?.city"
                             :key-value="{key:'province', value: 'id'}"/>
                </div>
              </template>
              <template v-slot:form-employees>
                <div class="px-3 py-2">
                  <div class="subtitle pb-3">¿Qué tamaño de empresa buscas?</div>
                  <div v-for="(w , index) in employees"
                       class=""
                       :key="index+'-works'">
                    <ui-check-box :label="w.name+' empleados'"
                                  @click="addArray('employees',w)"
                                  :vuelidate="v$.form.employees"
                                  :is-checked="inArray('employees',w)"
                                  class="h-100 d-flex align-items check-box"/>
                  </div>
                </div>
              </template>
              <template v-slot:form-area>
                <div class="px-3 py-2">
                  <div class="subtitle pb-3">¿Qué rango de superficie buscas?</div>
                  <div class="row">

                    <div class="col-6 p-0 m-0 pe-2">
                      <ui-select label="Mínimo"
                        :options="surfaceMinimum"
                        class="select-border"
                        @update:model-value="form.area['min'] = $event['value']"
                        :model-value="form.area.min"
                        :key-value="{key:'name', value: 'value'}"/>
                      <small class="text-cement-gray">En m²</small>
                    </div>

                    <div class="col-6 p-0 m-0 pe-2 ps-2">
                      <ui-select label="Máximo"
                        :options="surfaceMaximum"
                        class="select-border"
                        @update:model-value="form.area['max'] = $event['value']"
                        :model-value="form.area.max"
                        :key-value="{key:'name', value: 'value'}"/>
                      <small class="text-cement-gray">En m²</small>
                    </div>
<!--
                    <ui-text label="Mínimo"
                             class="col-6"
                             :model-value="form.area.min"
                             :vuelidate="v$.form?.area?.min"
                             :sub-label="'En m²'"
                             type="number"
                             @update:model-value="form.area.min = +$event"
                             placeholder="50"/>

                    <ui-text label="Máximo"
                             class="col-6"
                             :model-value="form.area.max"
                             :vuelidate="v$.form?.area?.max"
                             :sub-label="'En m²'"
                             type="number"
                             @update:model-value="form.area.max = +$event"
                             placeholder="50"/>
-->

                  </div>
                </div>
              </template>
            </accordion-vuelidate>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts"
        src="./CardProject.ts"/>
<style lang="scss">@import "CardProject";</style>
<template>
  <div class="CardProject">
    <div class="position-relative p-2">
      <div class="white-triangle"></div>
      <img class="company_img"
           v-if="picture"
           :src="picture"
           :alt="header+' Logo'">

      <img  v-else class="company_img"
           src="~@/assets/images/not_img.png"
           :alt="header+' Logo'">

      <img class="company_logo"
           v-if="logo"
           :src="logo"
           :alt="header+' Image'">
    </div>
    <div class="px-3 py-4">
      <div class="fw-bold company_name">{{ header }}</div>
      <div class="text-cement-gray company_detail">{{
          description && description.length > 100 ? description.substring(0, 100) + '...' : description
        }}
      </div>
    </div>
  </div>
</template>


<script lang="ts"
        src="./BannerAddCompany.ts"/>
<style lang="scss">@import "BannerAddCompany";</style>
<template>
  <div class="BannerAddCompany d-flex justify-content-between flex-column-sm align-items-center p-3">
    <div class="text-center ">¿Quieres darle visibilidad a tu empresa?</div>
    <p class="only-xs"></p>
    <div
        @click="$router.push('/rwc')"
        class="text-tile ">Añade tu empresa
    </div>
  </div>
</template>

<script lang="ts"
        src="./AuthContainer.ts"/>
<style lang="scss">@import "AuthContainer";</style>
<template>
  <div class="AuthContainer">
    <div class="bg-grey"></div>
    <div id="AuthContainer_content" class="container  d-flex justify-content-between align-items-center">

      <div id="box-text"
           class="w-100 h-100 d-flex justify-content-center  align-items-center position-relative hidden-xs">

        <img src="~@/assets/images/register/triangle-h.png"
             class="triangle-h"
             alt="triangle h">
        <img src="~@/assets/images/register/triangle-v.png"
             class="triangle-v"
             alt="triangle v">
        <div class="info">
          <slot name="left"></slot>
        </div>
      </div>
      <div
          class="w-100 d-flex justify-content-center align-items-center"
          id="container-form">

        <div id="right-section" >
          <slot name="right"></slot>
        </div>

      </div>
    </div>
  </div>
</template>

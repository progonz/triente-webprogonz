<script lang="ts"
        src="./BannerAddCompanyV2.ts"/>
<style lang="scss">@import "BannerAddCompanyV2";</style>
<template>
  <div class="BannerAddCompanyV2 bg-white p-4">
    <img src="~@/assets/images/graph_more.svg"
         alt="">
    <p class="py-1"></p>
    <div class="fs-5">¿Quieres darle visibilidad a tu empresa?</div>
    <p class="py-1"></p>
    <button type="button"
            @click="$router.push('/rwc')"
            class="btn btn-primary  text-center w-100">
      Añade tu empresa a Triente
    </button>
  </div>
</template>

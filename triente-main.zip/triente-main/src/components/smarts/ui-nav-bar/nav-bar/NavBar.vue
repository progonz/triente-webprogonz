<script lang="ts"
        src="./NavBar.ts"/>

<style lang="scss">
@import "NavBar";
</style>
<template>

  <div class="NavBar">
    <nav id="nav-bar"
         class="navbar navbar-expand-lg navbar-dark bg-dark p-0">
      <div class="container-fluid p-0">
        <button class="navbar-toggler "
                type="button"
                data-bs-toggle="collapse"
                aria-expanded="false"
                @click.stop="navOpen=!navOpen;moreOpen = null"
                aria-label="Toggle navigation">
          <span class="icon-fi_menu text-white fs-1"></span>
        </button>
        <a class="navbar-brand py-3 px-md-5"
           @click="$router.push('/')">
          <img src="@/assets/logo.svg"
               alt="Logo Triente"
               width="155"
               height="30"
               class="d-inline-block align-text-top">

        </a>
        <div class="collapse navbar-collapse"
             @mouseleave="navOpen = false"
             :class="{'show': navOpen}">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0 align-items-center justify-content-center">


            <li class="nav-item dropdown px-md-3">
              <a class="nav-link d-flex justify-content-between align-items-center"
                 @click="openOption(menuMore.COMPANIES)"
                 aria-expanded="false">
                {{ menuMore.COMPANIES }}
                <span class="icon-fi_chevron-down ms-3"></span>
              </a>

            </li>
            <li class="nav-item px-md-2">
              <a class="nav-link"
                 @click="$router.push('/know-me')">Conoce Triente
              </a>
            </li>

          </ul>
          <div class="d-flex  "
               v-if="!isLogged">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 justify-content-center align-content-center align-items-center">

              <li class="nav-item px-md-5">
                <a class="nav-link"
                   @click="$router.push('/sign-in')">Inicia Sesión
                </a>
              </li>
              <li class="nav-item triente-yellow py-3 px-md-5 ">
                <a @click="$router.push('/register')"
                   class="nav-link text-black">Prueba gratis
                </a>
              </li>
              <li class="only-xs w-100">
                <banner-navigation class="my-5"/>
              </li>
            </ul>
          </div>
          <div class="d-flex w-sm-100"
               v-else>
            <ul class="navbar-nav me-auto  justify-content-center align-content-center align-items-center w-sm-100">

              <li class="nav-item px-md-5 w-sm-100">
                <a class="nav-link hidden-xs"
                   @click="$router.push('/my-profile')">
                  {{ menuMore.PROFILE }}
                </a>
                <a class="nav-link only-xs d-flex justify-content-between align-items-center  w-sm-100 "
                   @click="openOption(menuMore.PROFILE)"
                   aria-expanded="false">
                  <div> {{ menuMore.PROFILE }}</div>
                  <span class="icon-fi_chevron-down ms-3"></span>
                </a>
                <banner-navigation class="my-5 only-xs"/>

              </li>

            </ul>
          </div>
        </div>
      </div>
    </nav>
    <div class="nav-megamenu bg-white animate__animated animate__bounceInDown"
         v-show="moreOpen === menuMore.PROFILE "
         @mouseleave="moreOpen=null">
      <div class="section-back-xs d-flex align-items-center gap-4"
           @click="moreOpen = false; navOpen= true">
        <span class="icon-fi_arrow-left fs-4"></span>
        <div class="fs-5">{{ moreOpen }}</div>
      </div>
      <ul class="menu-xs-navigation">
        <li v-for="(menu, index) in menuProfile"
            @click="moreOpen= null"
            :key="'menu-'+index">
          <router-link :to="menu.link"
                       exact>
            <span v-if="menu.icon"
                  class="icon  "
                  :class="menu.icon"></span>
            {{ menu.label }}
          </router-link>
        </li>
        <li @click="onLogout()">
          <a>Cerrar sesión</a>
        </li>
      </ul>
    </div>
    <explore-companies v-show="moreOpen === menuMore.COMPANIES "
                       @on-back="closeNavBar()"
                       class="nav-megamenu bg-white animate__animated animate__bounceInDown" ></explore-companies>

  </div>
  <advanced-search-dialog @onFinished="closeNavBar()"/>
</template>

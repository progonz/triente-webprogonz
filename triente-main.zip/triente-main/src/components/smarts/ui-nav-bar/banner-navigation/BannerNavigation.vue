<script lang="ts"
        src="./BannerNavigation.ts"/>
<style lang="scss">@import "BannerNavigation";</style>
<template>
  <div class="BannerNavigation">
    <div  class="p-4 do_it">
      <div class="fs-5 fw-bold">¿Quieres que busquemos las empresas que más se adaptan a tus necesidades?</div>
      <div class="py-4">Te ofrecemos un listado con las empresas que necesitas. No tardaremos más de 5 segundos en
        encontrarlas
      </div>
      <button type="button"

              data-bs-toggle="modal"
              data-bs-target="#idAdvanceSearch"
              class="btn  btn-primary w-100  btn-icon">
        <span> Sí, hazlo por mí</span>
        <span class="  icon-fi_arrow-up-right"></span>
      </button>
    </div>
  </div>
</template>

<script lang="ts" src="./ExploreCompanies.ts"></script>
<style lang="scss">@import "ExploreCompanies";</style>

<template>
  <div>
    <div class="  hidden-xs w-100">
      <div class="row pb-5 w-100">
        <div class="col-9">
          <div class="row">
            <div class="col-2">
              <a v-for="(a, index) in typeCompanies"
                 :key="index+'-item'"
                 class="nav-megamenu-a d-flex"
                 :class="{'active': companySelected?.id === a.id}"
                 @click="selectCompany(a)">
                <span>{{ a.name }}</span>
              </a>
            </div>

            <div class="col-4" style="max-height: 75vh; overflow-y: auto">
              <div class="row m-0 p-0">
                <a v-for="(a, index) in activities"
                   :key="index+'-item'"
                   class="nav-megamenu-b col-12"
                   style="max-height: 75vh; overflow: auto"
                   :class="{'active': a.id === activitySelected?.id}"
                   @click="selectActivity(a)">{{ a.name }}
                </a>
              </div>

            </div>
            <div class="col-4"
                 style="max-height: 75vh; overflow-y: auto">
              <a v-for="(a, index) in subActivities"
                   :key="index+'-item'"
                   class="nav-megamenu-b "
                   @click="selectedSubActivity(a)">{{ a.name }}
              </a>
            </div>
          </div>
        </div>

        <banner-navigation class=" col-3 "/>
      </div>

    </div>
    <div class="only-xs flex-column w-100">
      <div class="section-back-xs d-flex align-items-center gap-4" @click="onClose()">
        <span class="icon-fi_arrow-left fs-4"></span>
        <div class="fs-5">{{ moreOpen }}</div>
      </div>
      <div class="d-flex border-bottom">
        <div v-for="(a, index) in typeCompanies"
             :key="index+'-item'"
             class="nav-megamenu-a d-flex m-0 p-0 "
             :class="{'active': companySelected?.id === a.id}"
             @click="selectCompany( a)">
          <a class="p-3">{{ a.name }}</a>
        </div>
      </div>

      <div v-for="a of activities" :key="a.id"
           @click="selectActivity(a)">
        <div class="p-4 d-flex justify-content-between subtitle" :class="{'bg-black text-white': a.id === activitySelected?.id}">
          <div>{{ a.name }}</div>
          <span class="icon-fi_chevron-up fs-3" v-if="a.id === activitySelected?.id"></span>
          <span class="icon-fi_chevron-down fs-3" v-if="a.id !== activitySelected?.id"></span>
        </div>
        <template v-if="a.id === activitySelected?.id">
          <div v-for="a in subActivities"
               class="px-4 py-3 text-muted"
               @click.stop="selectedSubActivity(a)"
               :key="a.id">
            <a> {{ a.name }}</a>

          </div>
        </template>
      </div>

      <banner-navigation class="p-5"/>
    </div>
  </div>
</template>

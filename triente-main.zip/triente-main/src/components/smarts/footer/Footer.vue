<script lang="ts"
        src="./Footer.ts"/>

<style lang="scss">
@import "Footer";
</style>
<template>

  <footer class="pure-black">
    <div class="container d-flex flex-column">
      <div class="row p-5 flex-column-sm">
        <div class="col-12 col-md-5 m-0 p-0">
          <img src="@/assets/logo.svg"
               alt=""
               width="155"
               height="30"
               class="d-inline-block align-text-top mt-4">
          <div class="text-white my-5">Encuentra y conecta ahora con la empresa que necesitas. Descubre. Decide. Conecta</div>
        </div>
        <div class="col-12 col-md-7 m-0 p-0 row">
          <div class="col text-white "
               v-for="(value, name, index) in footer"
               :key="index">

            <div class="py-4">{{ name }}</div>
            <div v-for="(item, index) in value"
                 :key="index">

              <a v-if="item.text == 'Contacto'" :href="item.link" class="text-cement-gray my-1 footer-link">
                {{ item.text }}
              </a>
              <a v-else-if="item.text == 'Política de Privacidad'" href="/pdf/Politica.pdf" target="_blank" class="text-cement-gray my-1 footer-link">
                {{ item.text }}
              </a>
              <a v-else-if="item.text == 'Aviso Legal'" href="/pdf/Aviso.pdf" target="_blank" class="text-cement-gray my-1 footer-link">
                {{ item.text }}
              </a>
              <a v-else-if="item.text == 'Condiciones de uso'" href="/pdf/Condiciones.pdf" target="_blank" class="text-cement-gray my-1 footer-link">
                {{ item.text }}
              </a>
              <a v-else-if="item.text == 'Madrid' || item.text == 'Barcelona' || item.text == 'Valencia' || item.text == 'Murcia' || item.text == 'Zaragoza'" 
                @click="search(item.text)" 
                class="text-cement-gray my-1 footer-link">
                {{ item.text }}
              </a>
              <router-link v-else :to="item.link" class="text-cement-gray my-1 footer-link">
                {{ item.text }}
              </router-link>
              
            </div>
          </div>
        </div>

      </div>
      <div class="d-flex justify-content-between p-5 flex-column-sm"
           id="footer_footer">
        <div class="text-cement-gray order-md-1 order-2">Triente - Todos los derechos reservados · Copyright 2021</div>
        <div class="order-md-2 order-1 d-flex"
             id="footer_footer-icons-media">
          <a href="https://www.linkedin.com/company/triente/about/?viewAsMember=true" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_linkedin text-white"></a>
          <a href="https://www.facebook.com/Triente-109822811664034" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_facebook text-white"></a>
          <a href="https://www.instagram.com/triente.es/" target="_blank" rel="noopener noreferrer" class="icon-rs icon-fi_instagram text-white"></a>
        </div>
      </div>
    </div>
  </footer>
</template>

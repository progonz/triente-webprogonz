<script lang="ts"
        src="./BannerNewsletter.ts"/>
<style lang="scss">@import "BannerNewsletter";</style>
<template>
  <div class="BannerNewsletter lightgrey">
    <div  class="p-5 container">
      <div class="container d-flex flex-column-sm">
        <div class="col-md-8">
          <div class="text-tile pb-3">Únete al newsletter de Triente</div>
          <div class="fs-5">Recibe actualizaciones de Triente y de las
            <br>
            empresas que forman parte de la plataforma
          </div>
        </div>
        <div class="col-md-4">
          <div class="input-group my-3">
            <input type="text"
                   class="form-control"
                   placeholder="Escribe tu email"
                   aria-label="Sizing example input">
          </div>
          <div>
            <span class="icon-fi_shield"></span>
            <span class="text-cement-gray ms-2">Sólo te enviaremos información relevante para ti, sin spam.</span>
          </div>
          <p class="py-2"></p>
          <button type="button"
                  class="btn btn-h64 btn-primary btn-icon">
            Quiero apuntarme
            <span class=" ms-5 icon-fi_arrow-up-right"></span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts"
        src="./BannerLimited.ts"/>
<style lang="scss">@import "BannerLimited";</style>
<template>
  <div class="BannerLimited   "
       :style="{'display':isLogged?'none':'block'}">
    <div class="row m-0 p-0 "
         id="test-free">
      <div class="col-12 col-md-4 d-flex justify-content-center">
        <img src="~@/assets/images/rocket.svg "
             alt="">
      </div>
      <div class="col-12 col-md-4 p-0 py-md-5">
        <div class="fs-2">Prueba gratis ahora para ver las 3257 empresas</div>
        <div class="py-4">Realiza búsquedas y filtra de forma eficiente para encontrar las mejores empresas para tu proyecto y contacta con ellas en Triente</div>
      </div>
      <div class="col-12 col-md-4 p-0 pt-md-5 d-flex justify-content-between flex-column">
        <div class="px-4">
          <div class="d-flex  align-items-center my-3">
            <span class="icon-fi_check me-3 fs-5"></span>
            Accede a información de perfil más completa
          </div>
          <div class="d-flex  align-items-center my-3">
            <span class="icon-fi_check me-3 fs-5"></span>
            Consulta proyectos de la empresa
          </div>
          <div class="d-flex  align-items-center my-3">
            <span class="icon-fi_check me-3 fs-5"></span>
            Contacta a través de Triente
          </div>
        </div>
        <div class="d-flex justify-content-end align-items-end">
          <button type="button"
                  @click="$router.push('/rwc')"
                  class="btn btn-primary triente-yellow btn-h64 text-black ">Prueba gratis ahora
            <span class=" ms-5 icon-fi_arrow-up-right"></span>
          </button>
        </div>
      </div>

    </div>
  </div>
</template>

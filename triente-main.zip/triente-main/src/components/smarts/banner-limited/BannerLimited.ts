import {Options, Vue} from "vue-class-component";
import {useStore} from "vuex";
import {StateInterface} from "@/store";

@Options({
    components: {},
})
export default class BannerLimited extends Vue {

    store = useStore<StateInterface>();

    get isLogged(): boolean {
        return this.store.getters["auth/isUserLogin"];
    }
}

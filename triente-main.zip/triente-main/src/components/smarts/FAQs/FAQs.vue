<script lang="ts"
        src="./FAQs.ts"/>
<style lang="scss">@import "FAQs";</style>
<template>
  <div class=" FAQs row">
    <div class="col-12 col-md-4 h-100">
      <h1>Preguntas
        <br class="hidden-xs">
        Frecuentes
      </h1>
      <p class="py-3"></p>
      <a class="text-tile-dark1 ">¿Tienes más dudas?</a>
    </div>
    <div class="col-12 col-md-8">
      <ui-accordion :items="questions"/>
    </div>
  </div>
</template>

<script lang="ts"
        src="./CompanyFunction.ts"></script>
<style lang="scss">@import "CompanyFunction";</style>
<template>
  <div class="CompanyFunction">
    <form>
      <div class="form-row">
        <div class="form-group col-md-12">
          <label class="d-block mb-1">Actividad</label>
          <ui-select
            :urlApi="urlApi.ACTIVITIES"
            placeholder="Actividad"
            @update:model-value="selectActivity"
            :model-value="activitySelected"
            :typeCompany="selectedTypeCompany"
            :key-value="{key:'name', value: 'id'}" />
        </div>
      </div>
      <div class="form-row">
        <div class="form-group col-md-12">
          <label class="d-block mb-1">Subactividad</label>
          <ui-select
            :disabled="activitySelected == null"
            :key="subActivityKey"
            :urlApi="urlApi.ACTIVITIES"
            placeholder="Subactividad"
            @update:model-value="selectedSubActivity = $event; addActivity()"
            :model-value="form.activities"
            :parent="activitySelected"
            :key-value="{key:'name', value: 'id'}"/>
        </div>
      </div>
    </form>

    <ul class="list-group">
      <li
        v-for="(e, index) in form['activities']"
        :key="index"
        class="list-group-item"
      >
        <div>
          <span>
            {{ e.name }} ({{ e.parent?.name }})
          </span>
          <button type="button"
            @click="removeActivity(e)"
            class="btn btn-primary "
          >
            <span class="icon-fi_trash" role="button"></span>
          </button>
        </div>
      </li>
    </ul>
    <div class="py-3 pt-5 subtitle">Superficie edificable</div>
    <div class="row">
      <div class="col-12 col-md-6 p-0 m-0 pe-2">
        <ui-select label="Mínimo"
          :options="surfaceMinimum"
          class="select-border"
          @update:model-value="form.area['min'] = $event['value']"
          :model-value="surfaceMinimumValue"
          :key-value="{key:'name', value: 'value'}"/>

        <small class="text-cement-gray">En m²</small>
      </div>
      <div class="col-12 col-md-6 p-0 m-0 pe-2 ps-2">
        <ui-select label="Máximo"
          :options="surfaceMaximum"
          class="select-border"
          @update:model-value="form.area['max'] = $event['value']"
          :model-value="surfaceMaximumValue"
          :key-value="{key:'name', value: 'value'}"/>
        <small class="text-cement-gray">En m²</small>
      </div>
    </div>
    <div class="pb-3 subtitle">Importe proyectos</div>
    <div class="row">

      <div class="col-12 col-md-6 p-0 m-0 pe-2">
        <ui-select label="Mínimo"
          :options="budgetMinimum"
          class="select-border"
          @update:model-value="form.budget['min'] = $event['value']"
          :model-value="budgetMinimumValue"
          :key-value="{key:'name', value: 'value'}"/>

        <small class="text-cement-gray">En €</small>
      </div>

      <div class="col-12 col-md-6 p-0 m-0 pe-2 ps-2">
        <ui-select label="Máximo"
          :options="budgetMaximum"
          class="select-border"
          @update:model-value="form.budget['max'] = $event['value']"
          :model-value="budgetMaximumValue"
          :key-value="{key:'name', value: 'value'}"/>
        <small class="text-cement-gray">En €</small>
      </div>
    </div>

    <div class="mt-2">
      <label> Nº empleados</label>
      <div class="d-flex flex-wrap mt-2">
        <div v-for="(w , index) in employees"
             :key="index+'-works'">
          <ui-check-box :label="w.name"
            @click="form.employees = w"
            :vuelidate="vuelidate.employees"
            :is-checked="w.id === form.employees?.id"
            class="h-100 d-flex align-items-center justify-content-center check-box"/>
        </div>

      </div>
      <ui-form-message
        class="mb-2"
        :vuelidate="vuelidate?.employees"
      />

    </div>

    <div class="py-3"></div>
    <button type="button"
      v-if="txtButton"
      @click="updateChange()"
      class="btn btn-primary"
    >
      {{ txtButton }}
    </button>
  </div>
</template>

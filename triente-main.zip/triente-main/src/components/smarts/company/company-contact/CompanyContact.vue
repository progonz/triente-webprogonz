<script lang="ts"
        src="./CompanyContact.ts"/>
<style lang="scss">@import "CompanyContact";</style>
<template>
  <div class="CompanyContact">

    <div class="row p-0 m-0">

      <ui-text label="Email"
               class="col-12 col-md-8 m-0 p-0"
               :model-value="form.email"
               :vuelidate="vuelidate?.email"
               @update:model-value="form['email'] = $event"
               placeholder="marguis@elmeunebot.es"/>
      <ui-text label="Teléfono"
               class="col-12 col-md-4 m-0 p-0 ps-1"
               :model-value="form.phone"
               type="phone"
               :vuelidate="vuelidate?.phone"
               @update:model-value="form['phone'] = $event"
               placeholder="666 666 666"/>
    </div>


    <ui-text label="Link a tu web (opcional)"
             :model-value="getNetwork('web')"
             @update:model-value="setNetWork('web', $event)"/>

    <div class="small text-danger" v-if="!isValidUrl(getNetwork('web'))">
      Formato de url invalido
    </div>
    <div class="subtitle mt-4 mb-3">Redes sociales</div>

    <ui-text label="Linkedin (opcional)"
             :model-value="getNetwork('linkedin')"
             @update:model-value="setNetWork('linkedin', $event)"/>

    <div class="small text-danger" v-if="!isValidUrl(getNetwork('linkedin'))">
      Formato de url invalido
    </div>


    <ui-text label="Instragram (opcional)"
             :model-value="getNetwork('instagram')"
             @update:model-value="setNetWork('instagram', $event)"
             placeholder="www.example.com"/>
    <div class="small text-danger" v-if="!isValidUrl(getNetwork('instagram'))">
      Formato de url invalido
    </div>

    <ui-text label="Facebook (opcional)"
             :model-value="getNetwork('facebook')"
             @update:model-value="setNetWork('facebook', $event)"/>
    <div class="small text-danger" v-if="!isValidUrl(getNetwork('facebook'))">
      Formato de url invalido
    </div>

    <div class="pt-3"></div>
    <button type="button"
            v-if="txtButton"
            @click="updateChange()"
            class="btn btn-primary ">
      Actualizar cambios
    </button>
  </div>
</template>

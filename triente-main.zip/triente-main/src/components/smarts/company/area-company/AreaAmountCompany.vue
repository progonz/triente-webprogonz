<script lang="ts"
        src="./AreaAmountCompany.ts"/>
<style lang="scss">@import "AreaAmountCompany";</style>
<template>
  <div class="d-flex justify-content-around align-items-center align-self-md-center  w-100 area-amount-company flex-column-sm">
    <div v-for="(item, index) in detailValues"
         :key="'detail-'+index"
         class="detail-company d-flex justify-content-md-center align-items-md-center flex-md-column px-2">
      <div class="px-2  title_area_amount">
        <span :class="item.icon"
              class="me-2 hidden-xs"></span>
        <small class="fw-bold text-uppercase hidden-xs">{{ item.title }}</small>
      </div>
      <div class="content_area_amount">
        <span :class="item.icon"
              class="me-2 only-xs"></span>
        <small class="text-cement-gray"> {{ item.getValue(company) }}</small>
      </div>
    </div>
  </div>

</template>


<script lang="ts" src="./CardCompany.ts"></script>
<style lang="scss">@import "CardCompany";</style>
<template>
  <div class="CardCompany  b-bottom-lightgrey">
    <div class="detail-name d-flex  flex-column-sm">
      <div class="company-img position-relative" v-if="company?.picture?.url">
        <div class="white-triangle"></div>
        <img :src="company?.picture?.url"
             class="img-picture"
             :alt="'Picture '+company?.name">
        <img class="img-company only-xs"
             :src="company?.logo?.url"
             :alt="'logo '+ company?.name">
      </div>
      <span v-else class="icon-fi_image  text-center picture"></span>

      <div class="company-detail ">
        <div class="fs-2 fw-bold pt-3">{{ company?.name }}</div>
        <div class="text-cement-gray hidden-xs pb-1">{{ company?.description }}</div>
        <list-tags :tagsString="getTags"
                   childClass="py-2 hidden-xs "/>

      </div>
    </div>
    <div class="d-flex justify-content-between flex-column-sm">

      <div class="ps-4  d-flex justify-content-center align-items-center hidden-xs">
        <img class="img-company"
             v-if="company?.logo"
             :src="company?.logo.url"
             :alt="'logo '+ company?.name">
        <span v-else class="icon-fi_image  text-center logo-avatar"></span>

      </div>

      <div class="w-100   d-flex justify-content-center align-items-center ">
        <area-amount-company :company="company"/>

      </div>
      <div class="view-detail">
        <a
          :href="'/company/' + company?.id"
          target="_blank"
          class="btn btn-primary text-center text-nowrap"
        >
          Ver Perfil
        </a>
      </div>
    </div>
  </div>
</template>

import { Options, Vue } from 'vue-class-component';
import AreaAmountCompany from '@/components/smarts/company/area-company/AreaAmountCompany.vue';
import ListTags from '@/components/smarts/list-tags/ListTags.vue';
import { ICompany } from '@/models/company.model';

@Options({
  components: {
    AreaAmountCompany,
    ListTags
  },
  props: {
    company: Object,
  }
})
export default class CardCompany extends Vue {
  company!: ICompany;

  get getTags(): string[] {
    const typeTarget = Object.assign({}, this.company.type);
    const type = JSON.parse(JSON.stringify(typeTarget));
    if (type.name === "Constructora") {
      const activities = (this.company?.activities ?? []).map(e => {
        const parentTarget = Object.assign({}, e.parent);
        const parent = JSON.parse(JSON.stringify(parentTarget));
        return e.name+" ("+parent.name+")";
      });
      const building = (this.company?.buildings ?? []).map(e => e.name);
      return [...activities, ...building];
    }
    else {
      const activities = (this.company?.activities ?? []).map(e => e.name);
      const building = (this.company?.buildings ?? []).map(e => e.name);
      return [...activities, ...building];
    }    
  }
}

<script lang="ts" src="./CompanyPerformance.ts"></script>
<style lang="scss">@import "CompanyPerformance";</style>
<template>
  <div class="CompanyPerformance">
    <div class="pb-4 subtitle">¿Dónde suele trabajar tu empresa?</div>
    <Tree
      v-if="cityTree"
      class="tree"
      :nodes="[cityTree]"
      :custom-options="{
        treeEvents: {
          checked: {
            state: true,
            fn: nodeSelected
          }
        }
      }"
    />
    <ui-form-message class="mb-2" :vuelidate="vuelidate"/>
  </div>
</template>

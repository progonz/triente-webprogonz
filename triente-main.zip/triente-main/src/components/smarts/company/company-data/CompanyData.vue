<script lang="ts" src="./CompanyData.ts" />
<style lang="scss">@import "CompanyData";</style>
<template>
  <div class="CompanyData">
    <div class="pb-2">Tipo de empresa</div>
    <div class="pb-4 pt-2">
      <div class="d-flex gap-2">
        <div v-for="(type, index) in typeCompany" :key="'type_company_'+index">
          <ui-check-box :label="type.name"
            class="h-100 d-flex align-items-center justify-content-center check-box"
            @click="form.type = {id: type.id}"
            :vuelidate="vuelidate.type"
            :is-checked="type.id === form?.type.id"
            :value=" type.id"
          />
        </div>
      </div>
      <ui-form-message :vuelidate="vuelidate.type"/>
    </div>


    <div class="row p-0 m-0">
      <ui-text label="Nombre de la empresa"
               :model-value="form.name"
               class="col-12 col-md-8 m-0 p-0"
               :vuelidate="vuelidate?.name"
               @update:model-value="form.name = $event"
               placeholder="Fernández Molina"/>

      <div class="col-12 col-md-4 p-0 m-0 ps-2">

        <ui-text label="CIF"
                 :model-value="form.cif"
                 :vuelidate="vuelidate.cif"
                 @update:model-value="form.cif = $event"
                 placeholder="B-66666666"/>
      </div>
    </div>
    <ui-text-area label="Descripción (opcional)"
                  :model-value="form.description"
                  :vuelidate="vuelidate.description"
                  @update:model-value="form.description = $event"/>
    <div class="d-flex flex-row-reverse">
      <small class="text-cement-gray">Caracteres: {{ form.description && form.description.length ? 800 - form.description.length : 800 }}</small>
    </div>
    <div class="subtitle mt-4 mb-3">¿Dónde se ubica tu empresa?</div>
    <div class="row m-0 p-0">
      <ui-text label="País"
               class="col-12 col-md-6 p-0 m-0 p-0 "
               :model-value="form.address.country"
               :disabled="true"

               :vuelidate="vuelidate.address?.country"
               placeholder="Castellón"/>

      <ui-select :urlApi="urlApi.PROVINCES"
                 ref="provinceSelector"
                 class="col-12 col-md-6  p-0 m-0 ps-2"
                 :model-value="form.address.province"
                 :vuelidate="vuelidate.address?.province"
                 @update:model-value="form.address['province'] = $event['province']"
                 label="Provincia"
                 :key-value="{key:'province', value: 'province'}"/>

    </div>
    <div class="row m-0 p-0">

      <ui-select :urlApi="urlApi.CITIES"
                 class="col-12 col-md-8  p-0 m-0 p-0"
                 :model-value="form.address.city"
                 :vuelidate="vuelidate.address?.city"
                 @update:model-value="form.address['city'] = $event['city']"
                 label="Ciudad"
                 :queryParams="{province:form.address.province}"
                 :key-value="{key:'city', value: 'city'}"/>


      <ui-select :urlApi="urlApi.CITIES"
                 label="Código postal"
                 class="col-12 col-md-4 m-0 ps-2"
                 :model-value="form.address.zipcode"
                 :vuelidate="vuelidate.address?.zipcode"
                 @update:model-value="form.address['zipcode'] = $event['zipcode']"
                 :queryParams="{city:form.address.city,province:form.address.province}"
                 :key-value="{key:'zipcode', value: 'zipcode'}"/>
    </div>
    <ui-text label="Dirección"
             :model-value="form.address.address"
             :vuelidate="vuelidate?.address?.address"
             @update:model-value="form['address']['address'] = $event"
             placeholder=" "/>

    <div class="subtitle  my-2">Logo de tu empresa</div>
    <ui-input-img
        @update:model-value="form.logo = $event"
        @delete="deleteLogo()"
        :model-value="form.logo"/>
    <small class="text-cement-gray">Ratio 1:1</small>

    <div class="subtitle  my-2">Foto banner de tu empresa</div>
    <ui-input-img
        @update:model-value="form.photo = $event"
        @delete="deletePhoto()"
        :model-value="form.photo"/>
    <small class="text-cement-gray">Ratio 21:9</small>

    <div class="subtitle  my-2">Foto para la lista de resultados</div>
    <ui-input-img
        @update:model-value="form.picture = $event"
        @delete="deletePicture()"
        :model-value="form.picture"/>
    <small class="text-cement-gray">Ratio 1:1</small>

    <div class="pt-5"></div>

    <button type="button"
            v-if="txtButton"
            @click="updateChange()"
            class="btn btn-primary ">
      {{ txtButton }}
    </button>
  </div>
</template>

import {Options, Vue} from "vue-class-component";

@Options({
    components: {},
    props: {
        tagsString: Array,
        childClass: String,
        maxTags: Number
    }
})
export default class ListTags extends Vue {
    tagsString: string[] = [];
    childClass = '';
    maxTags: number;
    showMore = false;

    get items(): string[] {
        if (this.showMore) return this.tagsString;
        if (this.maxTags && this.maxTags < (this.tagsString ?? []).length)
            return [...this.tagsString].slice(0, this.maxTags);
        return this.tagsString ?? [];
    }

    get diff(): string[] {
        if (((this.tagsString ?? []).length - this.items.length) > 0) {
            return [...this.tagsString].slice(this.maxTags, this.tagsString.length);
        }
        return [];
    }

    toggleShowMore() {
        this.showMore = !this.showMore;
    }
}

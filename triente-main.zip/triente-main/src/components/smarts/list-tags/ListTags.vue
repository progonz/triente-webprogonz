<script lang="ts"
        src="./ListTags.ts"/>
<style lang="scss">@import "ListTags";</style>
<template>
  <div class="d-flex  ListTags flex-wrap {{childClass}}"
       @mouseleave="showMore = false"
       :class="childClass">
    <small class="chip-tag mb-2"
           v-for="(tag, index) in items"
           :key="index+'-tag'">{{ tag }}
    </small>
    <small class="chip-tag mb-2"
           @click="toggleShowMore()"
           v-if="diff.length!==0 && !showMore && maxTags">+{{ diff.length }}
    </small>
  </div>
</template>

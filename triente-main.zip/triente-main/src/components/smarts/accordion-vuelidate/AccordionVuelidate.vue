<script lang="ts"
        src="./AccordionVuelidate.ts"/>
<style lang="scss">@import "AccordionVuelidate";</style>
<template>
  <div class="AccordionVuelidate">
    <div class="d-flex justify-content-between flex-column">
      <div v-for="(tab, index) in sections"
           :key="tab">
        <div class="bg-black"
             v-if="showLinePosition & tab === activeTab"
             :style="{width:((index+1)*100)/(sections.length)+'%', height:'3px'}"></div>
        <div v-if="$slots[titleSection(tab)]"
             class="title-section fs-4 d-flex justify-content-between align-items-center">
          <div>
            <span class="me-3">{{ index + 1 }}</span>
            <slot :name="titleSection(tab)"></slot>
          </div>
          <span
              v-if="sections.indexOf(activeTab) >index"
              @click="activeTab = tab"
              class="icon-fi_edit-3"></span>
        </div>
        <div class="container py-3"
             v-if="$slots[infoSection(tab)] && sections.indexOf(activeTab) >index">
          <slot :name="infoSection(tab)"></slot>
        </div>
        <div class="container m-0 p-0 py-md-3 px-md-3"
             v-if="activeTab === tab">
          <slot :name="formSection(tab)"></slot>
          <div class="py-3"></div>
          <div class="d-flex align-items-center d-flex justify-content-end">
            <span v-if="enableBack && index!== 0"
                  class="me-4 back-action"
                  @click="switchTab(sections[index-1])">Atrás
            </span>
            <button type="button"
                    :class="{'allow-back':enableBack }"
                    @click="switchTab(sections.length>index?sections[index+1]:null)"
                    class="btn btn-primary btn-h64">
              {{ index + 1 === sections.length ? 'Finalizar' : 'Siguiente' }}

              <span v-if="index + 1 !== sections.length && enableBack"
                    class="icon-fi_arrow-right"></span>
            </button>
          </div>
        </div>
      </div>
    </div>


  </div>
</template>

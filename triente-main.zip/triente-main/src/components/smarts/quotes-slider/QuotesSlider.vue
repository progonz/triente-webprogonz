<script lang="ts"
        src="./QuotesSlider.ts"/>
<style lang="scss">@import "QuotesSlider";</style>
<template>

  <div class="QuotesSlider">
    <div class="d-flex justify-content-between flex-column-sm align-items-center-sm">
      <div class=" comments_info-title fs-2 fw-bold"> Lo que opinan de nosotros</div>
      <a class="fs-1 comments_info-actions">
        <span class="icon-fi_arrow-left"
              data-bs-target="#carouselComments"
              data-bs-slide="prev"></span>
        <span class="icon-fi_arrow-right"
              data-bs-target="#carouselComments"
              data-bs-slide="next">

        </span>
      </a>
    </div>
    <p class="pb-5 hidden-xs"></p>
    <div id="carouselComments"
         class="carousel carousel-dark slide"
         data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button type="button"
                data-bs-target="#carouselComments"
                data-bs-slide-to="0"
                class="active"
                aria-current="true"
                aria-label="Slide 1"></button>
        <button type="button"
                data-bs-target="#carouselComments"
                data-bs-slide-to="1"
                aria-label="Slide 2"></button>
        <button type="button"
                data-bs-target="#carouselComments"
                data-bs-slide-to="2"
                aria-label="Slide 3"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item mb-5"
             :data-slide-number="index"
             :class="{'active':index===0}"
             data-bs-interval="1500"
             v-for="(c, index) in comments"
             :key="'cmt-'+index">
          <div class="carousel-item_item mb-5">
            <div class="fs-1 d-flex position-relative comment-box ">
              <span style="font-size: 400%; line-height: 100%"
                    class="text-triente-yellow">"
              </span>
              <span> {{ c.comment }}</span>

            </div>
            <div class="d-flex justify-content-center align-items-center">
              <img :src="c.avatar"
                   alt="Avatar"
                   class="avatar">
              <div class="mx-4">
                <div class="fw-bold"> {{ c.name }}</div>
                <div class="text-cement-gray">{{ c.profession }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

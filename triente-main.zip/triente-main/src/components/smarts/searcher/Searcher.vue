<script lang="ts"
        src="./Searcher.ts"/>
<style lang="scss">@import "Searcher";</style>
<template>

  <ui-tab class="Searcher"
          ref="searchTab"
          :tab-active="companySelect?.name"
          @select="reloadTab"
          :tabs="ids">

    <template v-for="cr in idsPanel"
              v-slot:[cr]
              :key="cr">


      <ui-dialog v-if="isMobile" class="lightgrey only-xs w-100" :id="'searcher-dialog-movil'">
        <template v-slot:dialog-actions>


          <div class="d-flex w-100">
            <button type="button"
                    class="btn btn-primary w-100 btn-icon only-xs d-flex justify-content-center align-content-center">
              Buscar
              <span class="icon-fi_search px-3"></span>
            </button>
          </div>
        </template>
        <template v-slot:dialog-header>Búsqueda</template>
        <template v-slot:dialog-content>

          <ui-select :urlApi="urlApi.PROVINCES"
                 ref="provinceSelector"
                 class="w-100"
                 :model-value="getCity"
                 @update:model-value="(form.provinceName = $event) &&  this.validateReload()"
                  placeholder="Provincia"
                 :key="provinceKey"
                 :key-value="{key:'province', value: 'province'}"/>
          <!--
          <ui-select :options="provinces"
                     class="w-100"
                     @update:model-value="(form.provinceName = $event) &&  this.validateReload()"
                     :model-value="getCity"
                     placeholder="Provincia"
                     :key-value="{key:'province', value: 'province'}"/>
          -->
          <!--
          <ui-select :options="typeActivities"
                     class="w-100"
                     @update:model-value="selectActivity"
                     :model-value="activitySelected"
                     placeholder="Actividad"
                     :key-value="{key:'name', value: 'id'}"/>
          -->
          <ui-select :urlApi="urlApi.ACTIVITIES"
            placeholder="Actividad"
            class="w-100"
            @update:model-value="selectActivity"
            :model-value="activitySelected"
            :typeCompany="selectedTypeCompany"
            :key-value="{key:'name', value: 'id'}"/>

          <!--
          <ui-select placeholder="Subactividad"
                     :key="subActivityKey"
                     class="w-100"
                     @update:model-value="selectSubActivity"
                     :model-value="subActivitySelected"
                     :key-value="{key:'name', value: 'id'}"
                     :options="typSubActivities"/>
          -->
          <ui-select :urlApi="urlApi.ACTIVITIES"
            :key="subActivityKey"
            placeholder="Subactividad"
            class="w-100"
            @update:model-value="selectSubActivity"
            :model-value="subActivitySelected"
            :parent="activitySelected"
            :key-value="{key:'name', value: 'id'}"/>

        </template>
        <template v-slot:dialog-footer>
          <button class="btn btn-primary"
                  data-bs-dismiss="modal"
                  @click="onSearch()"
                  aria-label="Close">Aplicar filtro
          </button>
        </template>
      </ui-dialog>
      <div v-else class="d-flex  hidden-xs justify-content-center align-items-center Searcher_select">

      <ui-select :urlApi="urlApi.PROVINCES"
                 ref="provinceSelector"
                 class="w-100"
                 :model-value="getCity"
                 @update:model-value="(form.provinceName = $event) &&  this.validateReload()"
                  placeholder="Provincia"
                  :key="provinceKey"
                 :key-value="{key:'province', value: 'province'}"/>
          <!--
        <ui-select :options="provinces"
                   class="w-100"
                   @update:model-value="(form.provinceName = $event) &&  this.validateReload()"
                   :model-value="getCity"
                   placeholder="Provincia"
                   :key-value="{key:'province', value: 'province'}"/>
        -->
        <!--
        <ui-select :options="typeActivities"
                   class="w-100"
                   @update:model-value="selectActivity"
                   :model-value="activitySelected"
                   placeholder="Actividad"
                   :key-value="{key:'name', value: 'id'}"/>
        -->
        <ui-select :urlApi="urlApi.ACTIVITIES"
            placeholder="Actividad"
            class="w-100"
            @update:model-value="selectActivity"
            :model-value="activitySelected"
            :typeCompany="selectedTypeCompany"
            :key-value="{key:'name', value: 'id'}"/>
        <!--
        <ui-select placeholder="Subactividad"
                   :key="subActivityKey"
                   class="w-100"
                   @update:model-value="selectSubActivity"
                   :model-value="subActivitySelected"
                   :key-value="{key:'name', value: 'id'}"
                   :options="typSubActivities"/>
        -->
        <ui-select :urlApi="urlApi.ACTIVITIES"
            :key="subActivityKey"
            placeholder="Subactividad"
            class="w-100"
            @update:model-value="selectSubActivity"
            :model-value="subActivitySelected"
            :parent="activitySelected"
            :key-value="{key:'name', value: 'id'}"/>

        <div>

          <button type="button"
                  @click="onSearch()"
                  class="btn btn-primary me-2 my-1 p-3">
            <span class="icon-fi_search" role="button"></span>
          </button>
        </div>
      </div>

      <ui-dialog class="lightgrey" :id="'searcher-dialog'">
        <template v-slot:dialog-actions>
          <div class="text-tile-dark1 px-4 py-2 ">
            <small>Búsqueda avanzada</small>


          </div>
        </template>
        <template v-slot:dialog-tags>
          <div>
            <span class="filters-tags ms-2 px-2 py-1 small" v-if="infoFilters" @click.stop="clearFilter()" role="button">
              <span class="">{{ infoFilters }} filtros</span>
              <span class="icon-fi_x ps-1 text-muted " role="button"></span>
            </span>
          </div>
        </template>
        <template v-slot:dialog-header>Búsqueda avanzada</template>
        <template v-slot:dialog-content>
          <div>
            <ui-select :urlApi="urlApi.PROVINCES"
                 ref="provinceSelector"
                 class="w-100"
                 :model-value="getCity"
                 @update:model-value="(form.provinceName = $event) &&  this.validateReload()"
                  placeholder="Provincia"
                  :key="provinceKey"
                 :key-value="{key:'province', value: 'province'}"/>
                 <!--
            <ui-select :options="provinces"
                     class="w-100"
                     @update:model-value="(form.provinceName = $event) &&  this.validateReload()"
                     :model-value="getCity"
                     placeholder="Provincia"
                     :key-value="{key:'province', value: 'province'}"/>
                     -->
            <!--
            <ui-select :options="typeActivities"
                      class="w-100"
                      @update:model-value="selectActivity"
                      :model-value="activitySelected"
                      placeholder="Actividad"
                      :key-value="{key:'name', value: 'id'}"/>
            -->
            <ui-select :urlApi="urlApi.ACTIVITIES"
              placeholder="Actividad"
              class="w-100"
              @update:model-value="selectActivity"
              :model-value="activitySelected"
              :typeCompany="selectedTypeCompany"
              :key-value="{key:'name', value: 'id'}"/>
            <!--
            <ui-select placeholder="Subactividad"
                      :key="subActivityKey"
                      class="w-100"
                      @update:model-value="selectSubActivity"
                      :model-value="subActivitySelected"
                      :key-value="{key:'name', value: 'id'}"
                      :options="typSubActivities"/>
            -->
            <ui-select :urlApi="urlApi.ACTIVITIES"
              :key="subActivityKey"
              placeholder="Subactividad"
              class="w-100"
              @update:model-value="selectSubActivity"
              :model-value="subActivitySelected"
              :parent="activitySelected"
              :key-value="{key:'name', value: 'id'}"/>
            <!--
            <div class="fs-5 pb-2">Tipo de edificio</div>
            <div class="d-flex flex-wrap">
              <div v-for="(w , index) in typeBuildings"
                   :key="index+'-works'">
                <ui-check-box :label="w.name"
                              @click="addArray('buildings', w)"
                              :is-checked="inArray('buildings', w)"
                              class="h-100 d-flex align-items check-box"/>


              </div>
            </div>
            -->
            <div class="fs-5 pb-2">Nº empleados</div>
            <div class="d-flex flex-wrap">
              <div v-for="(w , index) in numEmployees"
                   :key="index+'-works'">
                <ui-check-box :label="w.name"
                              @click="addArray('employees', w)"
                              :is-checked="inArray('employees', w)"
                              class=" check-box"/>


              </div>


            </div>
            <div class="fs-5 pb-2">Superficie edificable</div>
            <div class="row">

              <div class="col-6 p-0 m-0 pe-2">
                <ui-select label="Mínimo"
                           :options="surfaceMinimum"
                           class="select-border"
                           @update:model-value="form.area['min'] = $event['value']"
                           :model-value="form.area.min"
                           :key-value="{key:'name', value: 'value'}"/>
                <small class="text-cement-gray">En m²</small>
              </div>

              <div class="col-6 p-0 m-0 pe-2 ps-2">
                <ui-select label="Máximo"
                           :options="surfaceMaximum"
                           class="select-border"
                           @update:model-value="form.area['max'] = $event['value']"
                           :model-value="form.area.max"
                           :key-value="{key:'name', value: 'value'}"/>
                <small class="text-cement-gray">En m²</small>
              </div>

            </div>
            <!--
                        <div class="row">
                          <ui-text label="Mínimo"
                                   class="col-6 p-0 m-0 pe-1"
                                   :model-value="form.area.min"
                                   :sub-label="'En m²'"
                                   type="number"
                                   @update:model-value="form.area.min = +$event"
                                   placeholder="50"/>
                          <ui-text label="Máximo"
                                   class="col-6 p-0 m-0 ps-1"
                                   :model-value="form.area.max"
                                   :sub-label="'En m²'"
                                   type="number"
                                   @update:model-value="form.area.max = +$event"
                                   placeholder="50"/>
                        </div>
            -->
            <div class="pb-2 fs-5">Importe proyectos</div>
            <div class="row">

              <div class="col-6 p-0 m-0 pe-2">
                <ui-select label="Mínimo"
                           :options="budgetMinimum"
                           class="select-border"
                           @update:model-value="form.budget['min'] = $event['value']"
                           :model-value="form.budget?.min"
                           :key-value="{key:'name', value: 'value'}"/>
                <small class="text-cement-gray">En €</small>
              </div>

              <div class="col-6 p-0 m-0 pe-2 ps-2">
                <ui-select label="Máximo"
                           :options="budgetMaximum"
                           class="select-border"
                           @update:model-value="form.budget['max'] = $event['value']"
                           :model-value="form.budget?.max"
                           :key-value="{key:'name', value: 'value'}"/>
                <small class="text-cement-gray">En €</small>
              </div>
              <!--
                            <ui-text label="Mínimo"
                                     class="col-6 p-0 m-0 pe-1"
                                     :model-value="form.budget?.min"
                                     type="number"
                                     :sub-label="'En €'"
                                     @update:model-value="form.budget.min = +$event"
                                     placeholder="50"/>
                            <ui-text label="Máximo"
                                     class="col-6 p-0 m-0 ps-1"
                                     :sub-label="'En €'"
                                     :model-value="form.budget?.max"
                                     type="number"
                                     @update:model-value="form.budget.max = +$event"
                                     placeholder="50"/>
              -->
            </div>
          </div>
        </template>
        <template v-slot:dialog-footer>
          <button class="px-5 btn"
                  data-bs-dismiss="modal"
                  aria-label="Close"> Restablecer
          </button>
          <button class="btn btn-primary"
                  data-bs-dismiss="modal"
                  @click="onSearch()"
                  aria-label="Close">Aplicar filtro
          </button>
        </template>
      </ui-dialog>

    </template>

  </ui-tab>
</template>

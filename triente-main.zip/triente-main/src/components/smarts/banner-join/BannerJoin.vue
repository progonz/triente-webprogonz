<script lang="ts"
        src="./BannerJoin.ts"/>
<style lang="scss">@import "BannerJoin";</style>
<template>
  <div class=" BannerJoin px-2  px-md-0 row flex-column-sm ">
    <div class="triente-yellow">

      <div class="col p-5">
        <h5 class="mb-5">Únete a Triente y descubre todo lo que podemos
          <br>
          hacer por ti
        </h5>

        <p>Consigue la empresa que necesitas para tu proyecto con Triente.
          <br>
          La plataforma de consulta de empresas de construcción donde está todo lo que buscas.
        </p>
      </div>
      <div class="col d-flex justify-content-end align-content-end align-items-end p-0 w-md-100">
        <button type="button"
                @click="$router.push('/rwc')"
                class="btn btn-primary btn-h64 w-md-100 ">
          Prueba gratis ahora
          <span class=" ms-5 icon-fi_arrow-up-right"></span>
        </button>
      </div>
    </div>
  </div>
</template>

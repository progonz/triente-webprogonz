<script lang="ts"
        src="./FindCompanies.ts"/>
<style lang="scss">@import "FindCompanies";</style>
<template>
  <div class=" FindCompanies position-relative">
    <div class=" row position-relative p-0 m-0">
      <div class="col m-0 p-0"
           id="images-discover">
        <div class=" bg-img-discover img-cover h-100"></div>

      </div>
      <div class="col-4 bg-multi-points img-cover bg-white hidden-xs">

      </div>

    </div>
    <div class="container position-relative"
         id="card-discover">
      <div class="pearl-black p-3 p-md-5 position-absolute w-auto bottom-0 card-discover_more">
        <h5 class="my-2">¿Quieres tomar la decisión correcta?</h5>
        <p class="py-1"></p>
        <h2 class="mt-4 ">Creamos una lista con las opciones más
          <br>
          adecuadas para ti.
        </h2>
        <p class="py-4"></p>


        <a type="button"
           data-bs-toggle="modal"
           data-bs-target="#idAdvanceSearch"
           class="btn btn-primary btn-h64  w-sm-100">Encontrar la empresa
          <span class=" ms-5 icon-fi_arrow-up-right"></span>
        </a>
      </div>
    </div>
  </div>
</template>

<script lang="ts"
        src="./EmptyResult.ts"/>
<style lang="scss">@import "EmptyResult";</style>
<template>
  <div class="EmptyResult d-flex justify-content-center flex-column align-items-center ">
    <img src="~@/assets/images/search-empty.png"
         alt="">
    <div class="fs-1 mb-3">¡Vaya!</div>
    <div class="fs-4 text-cement-gray text-center mb-5">Parece que no hay resultados para tu búsqueda.</div>
  </div>
</template>

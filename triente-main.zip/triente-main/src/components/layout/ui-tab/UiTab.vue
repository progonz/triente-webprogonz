<script lang="ts"
        src="./UiTab.ts"/>
<style lang="scss">@import "UiTab";</style>

<template>
  <div class="d-flex flex-column w-100 my-4 tab-content">
    <div class="d-flex justify-content-between">
      <a class="ui-tab"
           v-for="tab in tabs"
           :key="tab"
           :class="{'active': activeTab === tab}"
           @click="switchTab(tab)">
        <slot :name="tabHeadSlotName(tab)">{{ tab }}</slot>
      </a>
    </div>
    <div class="bg-white  tab-content-content">

      <slot :name="tabPanelSlotName"></slot>
    </div>
  </div>

</template>

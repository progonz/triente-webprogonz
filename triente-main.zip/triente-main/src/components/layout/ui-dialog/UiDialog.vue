<script lang="ts"
        src="./UiDialog.ts"/>
<style lang="scss">@import "UiDialog";</style>

<template>
  <div class="UiDialog">

  <div class="d-flex align-items-center ">
    <a class="w-100"
         data-bs-toggle="modal"
         :data-bs-target="'#'+id">
      <slot name="dialog-actions"></slot>
    </a>
    <slot name="dialog-tags"></slot>
  </div>
  <!-- Modal -->
  <div class="UiDialog modal fade"
       :id="id"
       data-bs-backdrop="static"
       data-bs-keyboard="false"
       tabindex="-1"
       :aria-labelledby="id+'-Label'"
       aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"
              :id="id+'-Label'">
            <slot name="dialog-header"></slot>
          </h5>
          <button type="button"
                  @click="closed()"
                  class="btn btn_close_dialog p-2"
                  data-bs-dismiss="modal"
                  aria-label="Close">
            <span class="icon-fi_x "></span>
          </button>
        </div>
        <div class="modal-body">
          <slot name="dialog-content"></slot>
        </div>
        <div class="modal-footer"
             v-if="$slots['dialog-footer']">
          <slot name="dialog-footer"></slot>
        </div>
      </div>
    </div>
  </div>
  </div>
</template>

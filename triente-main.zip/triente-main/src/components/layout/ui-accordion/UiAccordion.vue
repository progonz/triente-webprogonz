<script lang="ts"
        src="./UiAccordion.ts"/>
<style lang="scss">@import "UiAccordion";</style>
<template>
  <div v-for="(q, index) in items" :key="labelTab(index)" class="question_item">
    <div class="d-flex justify-content-between py-3" @click="onSwitcher(index)">
      <div class="fw-bold fs-5">{{ q.header }}</div>
      <span class="icon-fi_plus fs-5" v-show="!isActive(index)"></span>
      <span class="icon-fi_minus" v-show="isActive(index)"></span>
    </div>
    <transition name="bounce">
      <div class="text-cement-gray pb-4  "
           v-show="isActive(index)">
        {{ q.body }}
      </div>
    </transition>
  </div>

</template>
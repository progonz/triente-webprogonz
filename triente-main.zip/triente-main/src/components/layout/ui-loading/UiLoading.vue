<script lang="ts"
        src="./UiLoading.ts"/>
<style lang="scss">@import "UiLoading";</style>
<template>

  <div class="UiLoading d-flex justify-content-center align-items-center py-5">
    <img src="~@/assets/images/loading.svg"
         alt="email-sent"/>
  </div>
</template>
import {Options, Vue} from 'vue-class-component';

@Options({})
export default class UiLoading extends Vue {

}